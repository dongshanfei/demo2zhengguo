$(function(){
    //搜索
    $(".engine span").hover(function(){
        $("#en_list").show();
    },function(){
        $("#en_list").delay(2000).hide(0);
    });

    $("#en_list li").click(function(){
        $("#sea_en").html($(this).html());
    });
    $(".sea_btn").click(function(){
        var en_name = $("#sea_en img").attr("alt");
        console.log(en_name);
        if(en_name=="360"){
            window.open("https://www.so.com/s?q="+$("#keywords").val());
        }
        if(en_name=="baidu"){
            window.open("https://www.baidu.com/s?wd="+$("#keywords").val());
        }
        if(en_name=="google"){
            window.open("https://www.google.com/?#q="+$("#keywords").val());
        }
    });
    document.onkeydown=function(event){
        var e = event || window.event || arguments.callee.caller.arguments[0];
        if(e && e.keyCode == 13){
            $(".sea_btn").click();
        }
        if(e && e.keyCode==17){
           /* $(".txt").addClass("on").siblings().removeClass("on");
            $(".full_list a").show().css("opacity","1");
            $(".right_list a").show().css("opacity","1");*/
            $(".txt").click();
        }
    };


    //nav heightlight
    var nowurl = window.location.href;
    var navurl =["download","tech","seo","sem","brand","design"];
    for(var i=0;i<navurl.length;i++){
        if(nowurl.indexOf(navurl[i])>-1){
            $("nav li:eq("+(i+1)+")").addClass("on");
            $("nav li:eq(0)").removeClass("on");
        }
    }

    //LOGO文字切换
    $(".urlbox h3").append("<span class='on logo'>LOGO版</span><span class='txt'>文字版</span>");
    $(".urlbox h3 span").click(function(){
        //$(this).addClass("on").siblings().removeClass("on");
        if($(this).hasClass("logo")){
            //$(this).parent().parent().find(".full_list a").removeAttr("style");
            //$(this).parent().parent().find(".right_list a").removeAttr("style");
            $(".logo").addClass("on");
            $(".txt").removeClass("on");
            $(".full_list ul a").removeAttr("style");
            $(".right_list ul a").removeAttr("style");
        }
        if($(this).hasClass("txt")){
            //$(this).parent().parent().find(".full_list a").show().css("opacity","1");
            //$(this).parent().parent().find(".right_list a").css("opacity","1");
            $(".txt").addClass("on");
            $(".logo").removeClass("on");
            $(".full_list ul a").show().css("opacity","1");
            $(".right_list ul a").css("opacity","1");
        }
        if($(".txt").hasClass("on")){
            $(".urlbox ul a").hover(function(){
                $(this).css("opacity","0");
            },function(){
                $(this).css("opacity","1");
            })
        }
        if($(".logo").hasClass("on")){
            $(".urlbox ul a").hover(function(){
                $(this).css("opacity","1");
            },function(){
                $(this).css("opacity","0");
            })
        }
    });

    //
    for(var i=0;i<$("#word li").length;i++){
        var filetype = $("#word li:eq("+i+") a").attr("href");
        if(filetype.indexOf("ppt")>-1){
            $("#word li:eq("+i+") a").addClass("ppt");
        }
        if(filetype.indexOf("doc")>-1){
            $("#word li:eq("+i+") a").addClass("word");
        }
    }


    //页面定位跳转
    $("#dz").click(function(){
        window.open($(this).attr("href"));
    })
    $(".scroll,.nav li a,.nav h2 a").click(function(event) {
        event.preventDefault();
        var toid = $(this).attr("href");
        $("html,body").animate({scrollTop: $(toid).offset().top - 150}, {duration: 500,easing: "swing"});
    });
    //天气
    (function(T,h,i,n,k,P,a,g,e){g=function(){P=h.createElement(i);a=h.getElementsByTagName(i)[0];P.src=k;P.charset="utf-8";P.async=1;a.parentNode.insertBefore(P,a)};T["ThinkPageWeatherWidgetObject"]=n;T[n]||(T[n]=function(){(T[n].q=T[n].q||[]).push(arguments)});T[n].l=+new Date();if(T.attachEvent){T.attachEvent("onload",g)}else{T.addEventListener("load",g,false)}}(window,document,"script","tpwidget","//widget.seniverse.com/widget/chameleon.js"));
    tpwidget("init", {
        "flavor": "slim",
        "location": "WW0V9QP93VS8",
        "geolocation": "disabled",
        "language": "zh-chs",
        "unit": "c",
        "theme": "chameleon",
        "container": "tp-weather-widget",
        "bubble": "enabled",
        "alarmType": "badge",
        "color": "#FFFFFF",
        "uid": "U7D6A3502B",
        "hash": "510da6c3362431e28707c2466f343e99"
    });
    tpwidget("show");
});

window.onload = function(){
    function kill(){
        $(".copyright_2JjcV5R").hide();
    }
    setTimeout(kill,2000);

    //canvas
    var canvas = document.getElementById("cas");
    var ctx = canvas.getContext("2d");

    resize();
    window.onresize = resize;

    function resize() {
        canvas.width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        canvas.height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    }

    var RAF = (function() {
        return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(callback) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();

// 鼠标活动时，获取鼠标坐标
    var warea = {x: null, y: null, max: 20000};
    window.onmousemove = function(e) {
        e = e || window.event;

        warea.x = e.clientX;
        warea.y = e.clientY-50;
    };
    window.onmouseout = function(e) {
        warea.x = null;
        warea.y = null;
    };

// 添加粒子
// x，y为粒子坐标，xa, ya为粒子xy轴加速度，max为连线的最大距离
    var dots = [];
    for (var i = 0; i < 300; i++) {
        var x = Math.random() * canvas.width;
        var y = Math.random() * canvas.height;
        var xa = Math.random() * 2 - 1;
        var ya = Math.random() * 2 - 1;

        dots.push({
            x: x,
            y: y,
            xa: xa,
            ya: ya,
            max: 6000
        })
    }

// 延迟100秒开始执行动画，如果立即执行有时位置计算会出错
    setTimeout(function() {
        animate();
    }, 100);

// 每一帧循环的逻辑
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 将鼠标坐标添加进去，产生一个用于比对距离的点数组
        var ndots = [warea].concat(dots);

        dots.forEach(function(dot) {

            // 粒子位移
            dot.x += dot.xa;
            dot.y += dot.ya;

            // 遇到边界将加速度反向
            dot.xa *= (dot.x > canvas.width || dot.x < 0) ? -1 : 1;
            dot.ya *= (dot.y > canvas.height || dot.y < 0) ? -1 : 1;

            // 绘制点
            ctx.fillRect(dot.x - 0.5, dot.y - 0.5, 1, 1);

            // 循环比对粒子间的距离
            for (var i = 0; i < ndots.length; i++) {
                var d2 = ndots[i];

                if (dot === d2 || d2.x === null || d2.y === null) continue;

                var xc = dot.x - d2.x;
                var yc = dot.y - d2.y;

                // 两个粒子之间的距离
                var dis = xc * xc + yc * yc;

                // 距离比
                var ratio;

                // 如果两个粒子之间的距离小于粒子对象的max值，则在两个粒子间画线
                if (dis < d2.max) {

                    // 如果是鼠标，则让粒子向鼠标的位置移动
                    if (d2 === warea && dis > (d2.max / 2)) {
                        dot.x -= xc * 0.03;
                        dot.y -= yc * 0.03;
                    }

                    // 计算距离比
                    ratio = (d2.max - dis) / d2.max;

                    // 画线
                    ctx.beginPath();
                    ctx.lineWidth = ratio / 2;
                    ctx.strokeStyle = 'rgba(0,0,0,' + (ratio + 0.2) + ')';
                    ctx.moveTo(dot.x, dot.y);
                    ctx.lineTo(d2.x, d2.y);
                    ctx.stroke();
                }
            }

            // 将已经计算过的粒子从数组中删除
            ndots.splice(ndots.indexOf(dot), 1);
        });

        RAF(animate);
    }

}


