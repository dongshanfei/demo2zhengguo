$(function(){
	/*首页侧边隐藏导航栏*/
	$(".icon_menu").click(function(){
			$(".bg_mask").stop().fadeIn();
			$(".index_menu").animate({right:"0"},500);
			$("body").bind("touchmove",function(e){
				e.preventDefault();
			})
	})
	$(".bg_mask").click(function(){
			$(this).stop().fadeOut();
			$(".index_menu").animate({right:"-7.5rem"},500);
			$(".wechat_share").hide();
			$("body").unbind("touchmove");
	})

	/*首页搜索层弹出*/
	$(".icon_search").click(function(){
		$(".index_search").addClass("search_show").removeClass("search_hide");
		$("body").bind("touchmove",function(e){
			e.preventDefault();
		})
	})
	$(".go_back").click(function(){
		$(".index_search").removeClass("search_show").addClass("search_hide");
		$("body").unbind("touchmove");
	})

	/*首页banner轮播*/
	var mySwiper = new Swiper(".banner",{
		loop:true,
		pagination:'.swiper-pagination',
		autoplay:5000
	});

	var caseSwiper = new Swiper(".classic_case .swiper-container",{
		loop:true,
		initialSlide:"0",
		slidesPerView:"2",
		centeredSlides:true
	})
	/*微信关注*/
	$(".wechat").click(function(){
		$(".bg_mask").stop().fadeIn();
		$(".wechat_share").show();
		$("body").bind("touchmove",function(e){
			e.preventDefault();
		})
		
	})

	$(".btn_close").click(function(){
		$(".bg_mask").stop().fadeOut();
		$(this).parent().hide();
		$("body").unbind("touchmove");
	})
	/*返回顶部*/
	//$(window).scroll(function(){
	//	var top = $(window).scrollTop();
	//	if(top > 100){
	//		$(".back_top").fadeIn();
	//	}
	//	else{
	//		$(".back_top").fadeOut();
	//	}
	//})
	//$(".back_top").click(function(){
	//	$(window).scrollTop(0);  
	//})
	/*产品，案例头部导航*/
	if($(".column").length){
		var arr = $("title").html().split("-");
		var $lilist = $(".column ul li");
		var dataList = [];
		$lilist.each(function(){
			dataList.push($(this).attr("data-title"));
		})
		var index = jQuery.inArray(arr[0],dataList);
		if(!(index < 0) ){
			$lilist.eq(index).addClass("active").siblings("li").removeClass("active");
		}
		
	}
	/*产品详情页 小banner*/
	var productTab = new Swiper(".product_banner",{
		loop:true,
		pagination:'.swiper-pagination',
		autoplay:5000
	})
	/*产品详情页 相关案例*/
	var aboutCase = new Swiper("#about_case",{
		loop:true,
		initialSlide:"0",
		slidesPerView:"2",
		centeredSlides:true
	})

	/*产品详情页 选项卡*/
	// $(".product_moreInfo ul li").each(function(){
	// 	$(this).find(".intro_content").css("display","none");
	// 	$(this).find(".btn_display").click(function(){
	// 		$(this).find("span").toggleClass("select");
	// 		$(this).parent().siblings("li").find("span").removeClass("select");
	// 		$(this).parent().find(".intro_content").slideToggle(500);
	// 		$(this).parent().siblings("li").find(".intro_content").slideUp(500);
	// 	})
	// })
	/*表单ajax提交*/
	$(".submit").click(function(){
		var $product = $("input[name='product']");
		var $name = $("input[name='name']");
		var $tel = $("input[name='tel']");
		var $content = $("textarea");
		var $box = $("#warn_box");
		function hide(){
			setTimeout(function(){
				$box.fadeOut();
			},1000);
		}
		if($.trim($product.val())){
			if($.trim($name.val())){
				if($.trim($tel.val())){
					if($.trim($content.val())){
						$.ajax({
							method:"POST",
							url:'http://www.zzboiler.com/e/enews/index.php',
							data:$("#feedback").serialize(),
							beforeSend:function(){
							$(".submit").attr("disabled",true);
							},
							success:function(){
							$(".submit").attr("disabled",false);
							$box.html("提交成功").fadeIn(500,hide);
							$("input[type='text'],textarea").val("");
							}
						})
					}
					else{
						$box.html("请输入需求详情").fadeIn(500,hide);
						$content.focus();
						return false;
					}
				}
				else{
					$box.html("请输入联系电话").fadeIn(500,hide);
					$tel.focus();
					return false;
				}
			}
			else{
				$box.html("请输入姓名").fadeIn(500,hide);
				$name.focus();
				return false;
			}
		}
		else{
			$box.html("请输入产品名称").fadeIn(500,hide);
			$product.focus();
			return false;
		}
	})	
})


$(function(){
	if($(".news_content").length){
		$(".news_content img").removeAttr("height");
		$(".news_content p > span").removeAttr("style");
	}
})


$(function(){
	$(".column ul li").click(function(e){
		var e = e || event;
		var index = $(this).index();
		$(this).addClass('active').siblings().removeClass("active");
		$(".main .list").eq(index).show().siblings().hide();
	})
})