$(function(){
    var i=0;
    var clone=$(".special .img li").first().clone();
    $(".special .img").append(clone);
    var size=$(".special .img li").size();
    for(var j=0;j<size-1;j++){ 
        $(".special .num").append("<li></li>")
    }
    $(".special .num li").first().addClass("on");
    $(".special .num li").hover(function(){
        var index=$(this).index();
        i=index;
        $(".special .img") .stop().animate({left:-index*283},300)
        $(this).addClass("on").siblings().removeClass("on")
    })
    var t=setInterval(function(){
        i++
        move()
    },2000)
    $(".special").hover(function(){
        clearInterval(t);
    },function(){
        t=setInterval(function(){
            i++
            move()
        },2000)     })
    function move(){
        if(i==size){
            $(".special .img").css({left:0})
            i=1;      }
        if (i==-1){
            $(".special .img").css({left:-(size-1)*283})
            i=size-2;     }
        $(".special .img") .stop().animate({left:-i*283},300)
        if (i==size-1){
            $(".special .num li").eq(0).addClass("on").siblings().removeClass("on")
        }else{
            $(".special .num li").eq(i).addClass("on").siblings().removeClass("on")
        }
    }
})
$(function(){
	//multilang show
	$("#lang").hover(function(){
		$(this).parent().children(".multilang").stop().slideDown(200);
	},function(){
		var $lang = $(this).parent().children(".multilang");
		setTimeout(function(){
			if(!$lang.hasClass("hovered")){
				$lang.stop().slideUp(200);
			}
		},200)
	});
	$(".multilang").hover(
		function(){
			$(this).addClass("hovered");
		},
		function(){
			$(this).removeClass("hovered").stop().slideUp(200);
		});
	//fixed display
	var menutop = $("header .menu").offset().top;
	$(window).scroll(function(){
		var scrolltop = $("html,body").scrollTop() || $("body").scrollTop();
		if(scrolltop>menutop){
			$("header .menu").css({"position":"fixed","z-index":"1000","top":"0px","border-bottom":"1px solid #ccc"});
		}else{
			$("header .menu").css({"position":"static","border":"none"});
		}
		//goto show
		if(scrolltop > $(window).height()/2 ){
			$(".gotop").show();
		}else{
			$(".gotop").hide();
		}
	});
	//menu
	$(".menu ul li").hover(
			function(){
				$(this).children("ul").stop().slideDown(10);
			},
			function(){
				$(this).children("ul").stop().slideUp(10);
			});
	//product_channel
	$(".pchannel-second article").hover(function(){
		$(this).children("h1").children("a").css("color","#fc9000");
		$(this).find(".des").stop().animate({"bottom":"0px"},300);
	},
	function(){
		$(this).children("h1").children("a").css("color","#595757");
		$(this).find(".des").stop().animate({"bottom":"-148px"},300);
	});
	 var screenWidth=$(window).width();
        if(screenWidth<500){
        	$(".des").remove();
        }
	//product page
	$("main.single article.content .details .tag span:not(:last)").click(function(){
		var inx = $(this).index();
		$(this).addClass("selected").siblings().removeClass("selected");
		if(inx==0){
			$(".steampara").show(0);
			$(".waterpara").hide(0);
		}else{
			$(".steampara").hide(0);
			$(".waterpara").show(0);		
		}
		});
	$("main.single article.content .media").bind("click",function(){
		if($(".mediashowcase").length>0) return;
		var img = $(this).children("img").attr('data-bigimg-list');
		var imglist = img.split(';');
		$("body").append("<div class='mediashowcase' style='position:absolute;width:350px;height:250px;padding:20px;background:#fff;z-index:2048;box-shadow:5px 5px 50px #ccc'><a href='#' class='showcaseleft' style='position:absolute;left:2px;width:32px;height:55px;display:none;background:rgba(0,0,0,.2) url(\"../media/arrow.png\") 0 5px no-repeat'></a><a href='#' class='showcaseright' style='position:absolute;right:2px;width:32px;height:55px;display:none;background:rgba(0,0,0,.2) url(\"../media/arrow.png\") -104px 5px no-repeat'></a><div class='winshowcase-close' style='width:20px;height:20px;line-height:20px;text-align:center;color:#fff;background:red;position:absolute;right:0;top:0;cursor:pointer;font-size:12px'>X</div></div>");
		$(".mediashowcase").css({"top":($(window).height()-250)/2+"px","left":($(window).width()-350)/2+"px"});
		//showcase close
		$(".winshowcase-close").click(function(){
			$(this).parent().remove();
		});

		function insertimg(src,callback){
			var imgdom = new Image();
			imgdom.src = src;
			imgdom.onload=function(){
				callback(imgdom.width,imgdom.height,src);
			}
		}

		function changeshowcase(width,height,src){
			$(".mediashowcase img").remove();
			$(".mediashowcase").animate({"width":width+"px","height":height+"px","left":($(window).width()-width-40)/2+"px","top":($(window).height()-height-40)/2+$("body").scrollTop()+"px"},300,function(){
				$(".mediashowcase").append("<img src='"+src+"' style='display:none'>");
				$(".mediashowcase img").fadeIn();
				$(".mediashowcase a").css("top",($(".mediashowcase").height()-32)/2+"px");
			});
		}
		var index = 0;
		insertimg(imglist[index],changeshowcase);
		if(imglist.length>1){$(".mediashowcase a.showcaseright").show()};
		$(".mediashowcase a.showcaseright").click(function(){
			index++;
			if(index > 0){
				$(".mediashowcase a.showcaseleft").show();
			}
			insertimg(imglist[index],changeshowcase);
			if(imglist.length - index == 1){
				$(this).hide();
			}
		});
		$(".mediashowcase a.showcaseleft").click(function(){
			if(imglist.length>1){$(".mediashowcase a.showcaseright").show()};
			index--;
			insertimg(imglist[index],changeshowcase);
			if(index == 0){
				$(this).hide();
			}
		});
	});

	$("main.single article.content #case .win ul").wrap("<div class='psliderwin'></div>");
	$(".psliderwin").css({"height":$("main.single article.content #case .win ul").height(),"width":$("main.single article.content #case .win ul").width(),"margin":"0 auto","overflow":"hidden","float":"none"});
	$(".psliderwin ul").css({"width":$(".psliderwin ul li").length*306+"px","position":"relative"});
	$(".psliderwin ul li").css("float","left");

	$("main.single article.content #case .win .srocllleft").click(function(){
		if($(this).siblings("div").children("ul").is(":animated")) return;
		$(this).siblings("div").children("ul").stop().animate({'left':'-275px'},500,'swing',function(){
			$(this).css("left","0px");
			$(this).append($(this).children("li").eq(0).clone());
			$(this).children("li").eq(0).remove();
			var href = $(this).find("a").eq(0).attr("href");
			var title = $(this).find("img").eq(0).attr("alt");
			var span = $(this).find("li").eq(0).find("span");
			$(this).parent().parent(".win").siblings(".text").find("h3").text(title);
			$(this).parent().parent(".win").siblings(".text").find("a").attr("href",href);
			for(var i = 0 ; i < span.length ; i++){
				$(this).parent().parent(".win").siblings(".text").find("span").eq(i).text(span.eq(i).text());
			}
		});
	}).siblings(".srocllright").click(function(){
		if($(this).siblings("div").children("ul").is(":animated")) return;
		var thisul = $(this).siblings("div").children("ul");
		thisul.css("left","-275px");
		thisul.children("li").eq(0).before(thisul.children("li").last().clone());
		thisul.children("li").last().remove();
		thisul.animate({"left":"0px"},500);
		var href = thisul.find("a").eq(0).attr("href");
		var title = thisul.find("img").eq(0).attr("alt");
		var span = thisul.find("li").eq(0).find("span");
		thisul.parent().parent(".win").siblings(".text").find("h3").text(title);
		thisul.parent().parent(".win").siblings(".text").find("a").attr("href",href);
		for(var i = 0 ; i < span.length ; i++){
			thisul.parent().parent(".win").siblings(".text").find("span").eq(i).text(span.eq(i).text());
		}

	});

	$("main.single article.content #related-products ul li").hover(function(){
		$(this).find(".des").stop().slideDown(300);
	},
	function(){
		$(this).find(".des").stop().slideUp(300);
	});
	var screenWidth=$(window).width();
        if(screenWidth<500){
        	$(".des").remove();
        }

	//silider caselist banner
	var casethumb = $("aside .caselist .thumb li");
	for(var i =0 ;i < casethumb.length;i++){
		$("aside .caselist .holder").append("<span></span>");
	}
	$("aside .caselist .holder span").eq(0).addClass("selected");
	$("aside .caselist ul").eq(1).children("li").eq(0).addClass("on")
	$("aside .caselist .holder span").bind("click",function(){
		var index = $(this).index();
		$(this).addClass("selected").siblings().removeClass("selected");
		casethumb.fadeOut(0).eq(index).fadeIn(400);
		$("aside .caselist ul").eq(1).children("li").eq(index).addClass("on").siblings().removeClass("on");
	});

	$("aside .caselist ul").eq(1).children("li").bind("mouseenter",function(){
		var index = $(this).index();
		$("aside .caselist .holder span").eq(index).trigger("click");
	});

	//product_list
	///show product detail
	$("main.pchanne2 ul li").hover(function(){
		var product = $(this).find("h3").text();
		var imguri = $(this).find("img").attr("src");
		var descrip = $(this).find("p").html();
		var capareg = new RegExp(":(.*)$","g");
		var capa = capareg.exec($(this).find("p").children("span").eq(2).text())[1];
		var details = $(this).parents("article").find("section");
		details.find(".thumb").find("img").src=imguri;
		details.find(".thumb").find("span").text(capa);
		details.find(".description").html(descrip);
	});

	//download
	$("article.download .tag div").click(function(){
		var index = $(this).index();
		$(this).addClass("selected").siblings().removeClass("selected");
		$(this).parent(".tag").css("background-position",52+index*130+"px"+" 65px");
		$(this).parent(".tag").siblings(".pdflist").children("div").eq(index).show().siblings().hide();
	});

	//gotop
	$("body").append('<div class="gotop" style="position:fixed;right:20px;bottom:30px;background:rgba(0,0,0,.2) url(https://www.zgboilers.com/media/list_open.png) 8px center no-repeat;width:50px;height:50px;display:none;cursor:pointer"></div>');
	$(".gotop").click(function(){
		$("html,body").animate({"scrollTop":"0px"});
	});
	//mobile
	if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
		$(".menu nav ul ul").remove();
		$("main.single article.content .media").unbind("click");
		$(".mobile-menu-btn").click(function(){
			if($(this).siblings("ul").is(":hidden")){
				$(this).siblings("ul").slideDown(200);
				$(this).css("background-position","12px -96px");
			}else{
				$(this).siblings("ul").slideUp(200);
				$(this).css("background-position","12px -50px");
			}
		});
		$(".mobile-home-btn").click(function(){
			window.location.href="/";
		});
	};
	$(function (){
        var oneLiWidth = $(".about-l ul li").eq(0).width();     
        var marginValue = $(".about-l ul li").eq(0).css("margin-right");
        $(".about-l ul li").hover(function (){
            var curLeft = $(this).index()*oneLiWidth + parseInt(marginValue) * ($(this).index());
            $("#about-l-ho").animate({"left":curLeft}, 100)
        })
        var screenWidth=$(window).width();
        if(screenWidth<500){
        	$("#about-l-ho").remove();
        }
    })
})

/* Add unitCalc
 * by wang
 * 2016-11-28
 */
$(function(){
			$(".calc").css({"height":$("body").height()});
			/*点击显示计算框*/
			$("#calc").click(function(){
				$(".calc").removeClass("hide");
			})
			$(".calcunit").click(function(){
				$("#calc").trigger("click");
				return false;
			})
			$(".close").click(function(){
				$(this).parents(".calc").addClass("hide");
				$(".conver_btm li div").html("");
				$(".sourData").val("");
			})
			/*tab切换*/
			$(".changelist li").click(function(){
				$(this).addClass("select").siblings("li").removeClass("select");
				var index = $(this).index();
				$(".converterbox").eq(index).show().siblings("div").hide();
			})
			/*点击下拉菜单效果*/
			$(".unit_select").click(function(e){
				$(this).toggleClass("active");
				$(".unitlist").stop().fadeToggle();
				e.stopPropagation();
			})
			$(".changebox").click(function(){
				$(".unitlist").hide();
			})
			$(".sourData").bind("keydown",function(event){
				var e = event.keyCode; 
				if((e === 8 || (e > 45 && e < 58) ||(e >36 && e < 41)|| (e > 95 && e < 106) || e === 110) && (event.shiftKey == 0) ){
					return true;
				}
				else{
					event.returnValue=false;
					return false;
				}
			})
		/**************************************************
		 *热能单位转换
		 **************************************************/
			var Arr_heat = ["KW","MW","BHP","T/Hr","Kgs/Hr","Kcal/Hr","Btu/Hr","Btu/s","Lbs/Hr"];
			var len1 = Arr_heat.length;
			/*生成下拉菜单和目标转换单位*/
			for(var i = 0; i < len1;i++){
				$("<li/>").appendTo(".heatlist ul");
				$(".heatlist ul li").eq(i).html(Arr_heat[i]);
				$("<li><div/><span/></li>").appendTo("#heat_target");
				$("#heat_target li > span").eq(i).html(Arr_heat[i]);
			}
			/*热能单位选择*/
			$("#current_heat ul > li").click(function(){
				$("#current_heat > span").html($(this).text());
				$(".sourData:first").trigger("input");
			})
			var tarDate1 = [];
			function convKw(x){
				tarDate1 = [x,x/1000,x*0.102,x*1.33/1000,x*1.33,x*859.845,x*3412.142,x*0.9478,x*2.866];
			}
			function convMW(x){
				tarDate1 = [x*1000,x,x*102,x*1.3,x*1330,x*859845,x*947.8,x*3412142,x*2866];
			}
			function convBHP(x){
				tarDate1 = [x*9.81,x*9.81/1000,x,x*0.013,x*13.05,x*8434.65,x*33473.11,x*9.298,x*28.66];
			}
			function convTh(x){
				tarDate1 = [x*751.88,x*0.7519,x*76.6,x,x*1000,x*646500,x*2565521,x*712.6,x*2204];
			}
			function convKgs(x){
				tarDate1 = [x*0.75188,x/10e3*0.75188,x*0.0766,x/1000,x,x*646.5,x*2565.521,x*0.7126,x*2.204]
			}
			function convKcal(x){
				tarDate1 = [x/1000*1.163,x/10e5*1.163,x/10e3*1.1856,x/10e5*1.5,x/1000*1.547,x,x*3.968321,x/1000*1.102,x/1000*3.307];
			}
			function convBtuHr(x){
				tarDate1 = [x/10e3*2.931,x/10e6*2.931,x/10e4*2.99,x/10e6*3.9,x/10e3*3.898,x*0.2519958,x,x/10e3*2.778,x/10e3*8.591];
			}
			function convBtu(x){
				tarDate1 = [x*1.055,x*1.055/1000,x*0.1076,x*1.4/1000,x*1.403,x*907.185,x*3599.809,x,x*3.086];
			}
			function convLbs(x){
				tarDate1 = [x*0.3413,x/10e2*0.3413,x*0.03476,x/10e2*0.4536,x*0.4536,x*293.207,x*1163.54,x*0.323,x];
			}
			$(".sourData:first").bind("input",function(){
				var $sourData = $(this).val();
				if($sourData == ""){
					$("#heat_target li > div").html("");
				}
				else{
					$sourData = parseFloat($sourData);
					var $sourUnit = $("#current_heat > span").text();
					var index1 = $.inArray($sourUnit,Arr_heat);
					if(index1 === 0){convKw($sourData)};
					if(index1 === 1){convMW($sourData)};
					if(index1 === 2){convBHP($sourData)};
					if(index1 === 3){convTh($sourData)};
					if(index1 === 4){convKgs($sourData)};
					if(index1 === 5){convKcal($sourData)};
					if(index1 === 6){convBtuHr($sourData)};
					if(index1 === 7){convBtu($sourData)};
					if(index1 === 8){convLbs($sourData)};
					tarDate1 = $.map(tarDate1,function(i){
						if(i > 10e8-1){
							return i.toExponential(2);
						}
						else{
							return i.toFixed(2);
						}
					})
					for(var j = 0;j < len1;j++){
						$("#heat_target li > div").eq(j).html(tarDate1[j]);
					}
				}
			})	
		/**************************************************
		 *压力单位转换
		 *************************************************/
		 var Arr_press = ["bar","Mpa","psi","kgf/cm²"];
		 var len2 = Arr_press.length;
		 for(var m = 0;m < len2;m++){
		 	$("<li/>").appendTo(".presslist ul");
				$(".presslist ul li").eq(m).html(Arr_press[m]);
				$("<li><div/><span/></li>").appendTo("#press_target");
				$("#press_target li > span").eq(m).html(Arr_press[m]);
		 }
		 $("#current_press ul > li").click(function(){
				$("#current_press > span").html($(this).text());
				$(".sourData:eq(1)").trigger("input");
			})
		 var tarDate2 = [];
		 function convBar(x){
		 	tarDate2 = [x,x/10,x*14.5,x*1.02];
		 }
		 function convMpa(x){
		 	tarDate2 = [x*10,x,x*145,x*10.2];
		 }
		 function convPsi(x){
		 	tarDate2 = [x*0.06895,x/1000*6.895,x,x*0.0703];
		 }
		 function convKgf(x){
		 	tarDate2 = [x*0.9807,x*0.0981,x*14.2,x];
		 }
		 $(".sourData:eq(1)").bind("input",function(){
				var $sourData = $(this).val();
				if($sourData == ""){
					$("#press_target li > div").html("");
				}
				else{
					var $sourData = parseFloat($sourData);
					var $sourUnit = $("#current_press > span").text();
					var index2 =jQuery.inArray($sourUnit,Arr_press);
					if(index2 === 0){convBar($sourData)};
					if(index2 === 1){convMpa($sourData)};
					if(index2 === 2){convPsi($sourData)};
					if(index2 === 3){convKgf($sourData)};
					tarDate2 = $.map(tarDate2,function(i){
						if(i > 10e8-1){
							return i.toExponential(2);}
						else{
							return i.toFixed(2);
						}
					})
					for(var n = 0;n < len2;n++){
						$("#press_target li > div").eq(n).html(tarDate2[n]);
					}	
				}
			})
		/**************************************************
		 *温度转换
		 **************************************************/
		  var Arr_temp = ["°C","°F"];
		  var len3 = Arr_temp.length;
		  for(var k = 0;k < len3;k++){
		 	$("<li/>").appendTo(".templist ul");
				$(".templist ul li").eq(k).html(Arr_temp[k]);
				$("<li><div/><span/></li>").appendTo("#temp_target");
				$("#temp_target li > span").eq(k).html(Arr_temp[k]);
		 }
		 $("#current_temp ul > li").click(function(){
				$("#current_temp > span").html($(this).text());
				$(".sourData:last").trigger("input");
			})
		 var tarDate3 = [];
		 function convC(x){
		 	tarDate3 = [x,x*1.8+32];
		 }
		 function convF(x){
		 	tarDate3 = [(x-32)/1.8,x];
		 }
		 $(".sourData:last").bind("input",function(){
		 	var $sourData = $(this).val();
				if($sourData == ""){
					$("#press_target li > div").html("");
				}
				else{
					$sourData = parseFloat($sourData);
					var $sourUnit = $("#current_temp > span").text();
					var index3 =jQuery.inArray($sourUnit,Arr_temp);
					if(index3 === 0){convC($sourData)};
					if(index3 === 1){convF($sourData)};
					tarDate3 = $.map(tarDate3,function(i){
						if(i > 10e8){
							return i.toExponential(2);
						}
						else{
							return i.toFixed(2);
						}
					})
					for(var l = 0;l < len3;l++){
						$("#temp_target li > div").eq(l).html(tarDate3[l]);
					}
				}		
		 })	
		 if($("#unitCovern").length > 0){
		 	$("#unitCovern").click(function(){
		 		$("#calc").trigger("click");
		 	})
		 }
})


/*12.7 by wang*/
$(function(){
	$(".nav a:not(:last)").click(function(){
		var $text = $(this).attr("href");
		var top = $($text).offset().top -60;
		$("body").animate({scrollTop:top},1000);
		return false;
	})
})
//12.15 add
$(function(){
	$("#btnCover").click(function(){
		$("#calc").click();
	})
})

//17.01.09 add
$(function(){
	if($('.scrollwin').length > 0){
		$('.scrollwin ul li').hover(function(){
			$(this).find('h3').stop().animate({'height':'40px','line-height':'40px'});
		},function(){
			$(this).find('h3').stop().animate({'height':'20px','line-height':'20px'});
		})
	}
})