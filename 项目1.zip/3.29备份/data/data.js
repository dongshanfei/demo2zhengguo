[
    {
        "img": "../images/projectsImage.jpg",
        "title": "ZG30-5.29T CFB Boiler in Garment Factory",
        "content": "Application area : Gas boiler for rubber tire processing"
    },
    {
        "img": "../images/projectsImage.jpg",
        "title": "ZG30-5.29T CFB Boiler in Garment Factory",
        "content": "Application area : Gas boiler for rubber tire processing"
    }
]