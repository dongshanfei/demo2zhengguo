function type( obj ){
		var o = {};
		return o.toString.call(obj).slice(8,-1).toLowerCase(); 
	}
console.log(type(function(a){
	return a;
}));
