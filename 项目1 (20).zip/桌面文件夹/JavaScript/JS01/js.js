
function dispalyAbbr(){
	var abbr  = document.getElementsByTagName("abbr");
			var Arrlist = [];
			for(var i = 0;i < abbr.length;i++){
				var desc = abbr[i].getAttribute("title");
				var key = abbr[i].lastChild.nodeValue;
					Arrlist[key] = desc;		
			}
			var dllist = document.createElement("dl");
			for(key in Arrlist){
				var desc = Arrlist[key];
				var dtitle = document.createElement("dt");
				dtitle.innerHTML = key;
				var ddesc = document.createElement("dd");
				ddesc.innerHTML = desc;
				dllist.appendChild(dtitle);
				dllist.appendChild(ddesc);
			}
			var head = document.createElement("h2");
				var head_text = document.createTextNode("Abbreviations");
				head.appendChild(head_text);
				document.body.appendChild(head);
				document.body.appendChild(dllist);
}
addFunction(dispalyAbbr);
