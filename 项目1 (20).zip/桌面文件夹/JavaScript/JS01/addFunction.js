function addFunction(Func){
	var oldload = window.onload;
	if(typeof oldload != 'function'){
	window.onload = Func;
	}
	else{
		window.onload = function(){
			oldload();
			Func();
		}
	}
}

