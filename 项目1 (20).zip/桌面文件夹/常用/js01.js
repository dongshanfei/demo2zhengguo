$(function(){
	alert("hello world");
})