$(function(){
	$("p").css("color","#ff3200");
})