var loc = "";
var script = document.createElement("script");
script.src = "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js";
document.body.appendChild(script);
script.onload = function() {
	loc = remote_ip_info.province + remote_ip_info.city;
	document.body.removeChild(script);
}
script.onerror = function() {
	document.body.removeChild(script);
}
setInterval(function() {
	var chat = document.getElementById("LRdiv1");
	var myinvitation = document.getElementById("myinvitation");
	if (chat && chat.style.display == 'block') {
		var note = (chat.getElementsByTagName("p").length > 0 ? chat.getElementsByTagName("p")[0].innerHTML : document.getElementById("LR_Tb4").innerHTML.replace(/<[^>]*>/g, ""));
		if (!myinvitation) chatwin(note);
	}
}, 300)

function My_RefuseChat() {
	LR_RefuseChat();
	document.body.removeChild(document.getElementById('myinvitation'));
}

function chatwin(note) {
	var title = loc == "" ? "欢迎访问我们的网站" : "欢迎来自" + loc + "的朋友";
	var invitation = document.createElement("div");
	invitation.id = "myinvitation";
	invitation.style.cssText = "width:400px;height:202px;position: fixed !important;top:50%;left:50%;margin-top:-110px !important;margin-left:-211px !important;border: 1px solid #ccc;box-shadow: rgb(153, 153, 153) 0px 0px 18px;border-radius: 4px;z-index:9999999999;zoom:1;overflow: hidden;display:inline;background-color:#ffffff";
	invitation.innerHTML = "<div style=\"width:384px;margin:0 auto;margin-bottom:9px;\"><div style=\"width:384px;border-bottom:1px solid #efefef;height:40px;margin-bottom:3px;\"><p style=\"width:90%;line-height:40px;background:url(http://www.zzboiler.com/swt/map.png) no-repeat left center;text-indent: 2em;float:left;margin:0;padding:0;\">" + title + "</p><a id=\"closeone\" onclick=\'LR_HideInvite();My_RefuseChat();return false;\' style=\"width:10%;height:40px;background:url(http://www.zzboiler.com/swt/close.png) no-repeat right center;display: block;cursor: pointer;float:left;line-height: 40px\"></a></div><div style=\"width:384px;height:114px;\"><div style=\"width:28%;height:114px;background:url(http://www.zzboiler.com/swt/kefu.jpg) no-repeat left center;float: left;\"></div><div style=\"float: left;width:70%;\"><p style=\"height:auto;line-height: 20px;font-size: 13px;color:#848484;margin-bottom:10px;margin:0;padding:0\">" + note + "</p><p style=\"line-height: 20px;font-size: 13px;color:#848484;margin-bottom:8px;\">24小时咨询热线： <b>400-839-1110</b></p></div></div></div><div style=\"height:35px;width:400px;overflow: hidden;display:block;margin:0 auto\"><a href=\"#\"  id=\"closetwo\" onclick=\'LR_HideInvite();My_RefuseChat();return false;\' style=\"height: 35px;width:200px;background:url(http://www.zzboiler.com/swt/xx.gif) no-repeat center;display: block;float: left;\"></a><a href=\"javascript:void(0);\" onclick=\"openZoosUrl('chatwin')\" target=\"_blank\" style=\"height: 35px;width:200px;display: block;background:url(http://www.zzboiler.com/swt/jj.gif) no-repeat center;float: left;\"></a></div>";
	document.body.appendChild(invitation);
}
document.write("<div id=\"LRfloatright\"><img src=\"http://www.zzboiler.com/swt/swt.png\" onclick=\"openZoosUrl('chatwin');\" style=\"cursor:pointer\" target=\"_blank\"></div>");
if(document.all){
	/*if(navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion .split(";")[1].replace(/[ ]/g,"")=="MSIE7.0"){*/
		/*兼容IE7*/
		var cssNode = document.createStyleSheet();
		cssNode.addRule("img","border:none;");
		cssNode.addRule("#LRfloater0","opacity:0;filter:alpha(opacity=0);");
		cssNode.addRule("#LRfloatright","position: fixed !important;right:0 !important;top:150px !important;z-index:9999999999;}.lxb-container{top:250px !important;")
	/*}else{
		window.style = "img{border:none}#LRdiv0{opacity:0;filter:alpha(opacity=0);}#LRdiv1{opacity:0;filter:alpha(opacity=0);}#LRfloater0{opacity:0;filter:alpha(opacity=0);}#LRfloatright{position: fixed !important;right:0 !important;top:150px !important;z-index:9999999999;}.lxb-container{top:250px !important;}";
		document.createStyleSheet("javascript:style");
	}*/
}else{
	var style = document.createElement('style');
	style.type = 'text/css';
	style.innerHTML = "img{border:none}#LRdiv0{opacity:0;filter:alpha(opacity=0);}#LRdiv1{opacity:0;filter:alpha(opacity=0);}#LRfloater1{opacity:0;filter:alpha(opacity=0);}#LRfloatright{position: fixed !important;right:0 !important;top:150px !important;z-index:9999999999;}.lxb-container{top:250px !important;}";
	document.getElementsByTagName('HEAD').item(0).appendChild(style);
}
