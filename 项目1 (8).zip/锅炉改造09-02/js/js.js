$(function(){
	if($.browser.msie && $.browser.version == 6){
		$(".baiduSearch").niceScroll({
			railpadding:{top:0,right:296,left:0,bottom:0}
		})
	}
	else{
		$(".baiduSearch").niceScroll({
		 cursorcolor: "#4a93ef",//#CC0071 光标颜色
         cursoropacitymax: 1, //改变不透明度非常光标处于活动状态（scrollabar“可见”状态），范围从1到0
         touchbehavior: false, //使光标拖动滚动像在台式电脑触摸设备
         cursorwidth: "7px", //像素光标的宽度
         cursorborder: "0", // 	游标边框css定义
         cursorborderradius: "7px",//以像素为光标边界半径
         autohidemode: false ,//是否隐藏滚动条
         railpadding:{top:0,right:0,left:-4,bottom:0}
		})
	}	
})

$(function(){
	var imgLen = $(".tabYear img").length;
	for(var i = 0; i < imgLen;i++){
		$(".list").append("<span/>");
	}

	$(".list span").eq(0).addClass("select");
	$(".list span").hover(function(){
		$(this).addClass("select").siblings("span").removeClass("select");
		var index = $(this).index();
		$(".tabYear img").eq(index).show().siblings("img").hide();
		$(".txtCon").eq(index).show().siblings("div").hide();
		$(".cont ul li").eq(index).addClass("active").siblings().removeClass("active");
	})

	$(".cont ul li").hover(function(){
		var liIndex = $(this).index();
		$(".list span").eq(liIndex).trigger("mouseenter");
	})
	/*var i = 0;
	var timer = setInterval(function(){
		i++;
		if(i > 4){
		i = 0;}
		$(".list span").eq(i).trigger("mouseenter");
	},3000);
	$()*/
})

$(function(){
	$(".partOne ul li").click(function(){
		$(this).addClass("onSelect").siblings("li").removeClass("onSelect");
		var index = $(this).index();
		$(".mainCon").eq(index).show().siblings(".mainCon").hide();
	})
})
$(function(){
	$(".partThree ul li").hover(function(){
		$(this).addClass("on").siblings("li").removeClass("on");
	})
})



/*改造方案文字部分限制以及弹出层*/
$(function(){
		var self = $("p[limit]");
		var textArr = [];
		self.each(function(){
			var objString = $(this).text();
			var objLength = $(this).text().length;
			var num = $(this).attr("limit");
			textArr.push(objString);
			if(objLength > num){	
				$(this).text(objString.substring(0,num)+" ... ")
			}
			var alink = "<a href='javascript:void(0);' class='linkBox'>了解详情\></a>";
			$(this).append(alink);	
		})
			$.each($(".linkBox"),function(i,val){
				$(".linkBox").eq(i).click(function(){
					$(".mask,.alertBox").show();
					var oDiv = $(".partTwo").children("div");
					$(oDiv).eq(i).children("h4").clone().insertAfter($(".turnOff"));
					$(oDiv).eq(i).children("img").clone().insertAfter($(".alertBox h4"));
					$("<p/>").text(textArr[i]).insertBefore($(".askUs"));
				})
			})
			$(".turnOff").click(function(){
				$(".alertBox").children("h4,img,p").remove();
				$(".mask,.alertBox").hide();
			})
});

$(function(){
	var $inpTxt = $(".yourInfo input[type='text']");
            $inpTxt.each(function(){
            $(this).focus(function(){
                if($(this).val() == this.defaultValue){
                    $(this).val("");    
                }
            }).blur(function(){
                if($(this).val()==""){
                    $(this).val(this.defaultValue); 
                }
            })
        });

    	$("#content").focus(function(){
    		if($(this).val() == this.defaultValue){
    			$(this).val("");
    		}
    	}).blur(function(){
    		if($(this).val() == ""){
    			$(this).val(this.defaultValue);
    		}
    	})

})

$(function(){
	if($.browser.msie && $.browser.version == 6){
		$("#goHead").remove();
	}
	$("#goHead").hide();
	$(window).scroll(function(){
		if($(window).scrollTop() >1000 ){
			$("#goHead").show();
		}
		else{
			$("#goHead").hide();
		}
	})
	$(".go").click(function(){
		$("body,html").animate({scrollTop:0},500);
	})
})
function lycheck() {
        if (document.feedback.name.value == "" || document.feedback.name.value=="* 请输入您的真实姓名") {
            alert("请输入您的真实姓名");
            document.feedback.name.focus();
            return false;
        }
        
        if (document.feedback.tel.value == "" || document.feedback.tel.value=="* 请输入您的联系电话") {
            alert("请输入您的联系电话");
            document.feedback.tel.focus();
            return false;
        }
        if (document.feedback.address.value == "" || document.feedback.address.value=="* 请输入您所在的地址") {
            alert("请输入您所在的地址");
            document.feedback.address.focus();
            return false;
        }
        if (document.feedback.content.value == "" || document.feedback.content.value=="* 请在这里填写您的需求详情") {
            alert("请填写您的需求详情");
            document.feedback.content.focus();
            return false;
        }
    };

