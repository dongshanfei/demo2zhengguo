
$(".e .f").hover(function(){
    var index = $(this).index();
    $(this).addClass('col').siblings().removeClass('col')
    $(this).siblings(".f-all").find(".f-content").eq(index).removeClass("hide").siblings().addClass("hide")

})


// 第一种写法
    // $(".h .one img").hover(function(){
    //     $(this).siblings(".animatecss").animate({top:'0'})
    //     $(this).siblings(".animatecss").addClass("dis")
    // },function(){
    //      $(this).siblings(".animatecss").animate({top:'517'})
    //      $(this).siblings(".animatecss").removeClass("dis")
    // })


    // $(".h img").hover(function(){ 
    //     $(this).siblings(".animatecss-2").animate({top:'0'})
    //     $(this).siblings(".animatecss-2").addClass("dis")
    // },function(){
    //      $(this).siblings(".animatecss-2").animate({top:'235'})
    //      $(this).siblings(".animatecss-2").removeClass("dis")
    // })

// 第二种写法
    // $(".h .one img").mouseenter(function(){
    //     $(this).siblings(".animatecss").animate({top:'0'})
    //     $(this).siblings(".animatecss").addClass("dis")
    // })
    // $(".h .one .animatecss").mouseleave(function(){
    //     $(this).animate({top:'517'})
    //     $(this).removeClass("dis")
    // })
    // $(".h img").mouseenter(function(){ 
    //     $(this).siblings(".animatecss-2").animate({top:'0'})
    //     $(this).siblings(".animatecss-2").addClass("dis")
    // })
    // $(".h .animatecss-2").mouseleave(function(){ 
    //     $(this).animate({top:'235'})
    //     $(this).removeClass("dis")
    // })
// 第三种写法
    $('.h').on('mouseover',function(e){
        e.stopPropagation();        
    })
    $('.h .one img').on('mouseenter',function(){
        $(this).siblings(".animatecss").animate({top:'0'})
         $(this).siblings(".animatecss").addClass("dis")
    }) 
    $('.h .one .animatecss').on('mouseleave',function(){
       $(this).animate({top:'517'})
        $(this).removeClass("dis")
    })
    $('.h').on('mouseover',function(e){
        e.stopPropagation();        
    })
    $('.h .two img').on('mouseenter',function(){
        $(this).siblings(".animatecss-2").animate({top:'0'})
         $(this).siblings(".animatecss-2").addClass("dis")
    }) 
    $('.h .two .animatecss-2').on('mouseleave',function(){
       $(this).animate({top:'235'})
        $(this).removeClass("dis")
    })
    $('.h').on('mouseover',function(e){
        e.stopPropagation();        
    })
    $('.h .three img').on('mouseenter',function(){
        $(this).siblings(".animatecss-2").animate({top:'0'})
         $(this).siblings(".animatecss-2").addClass("dis")
    }) 
    $('.h .three .animatecss-2').on('mouseleave',function(){
       $(this).animate({top:'235'})
        $(this).removeClass("dis")
    })
    $('.h').on('mouseover',function(e){
        e.stopPropagation();        
    })
    $('.h .four img').on('mouseenter',function(){
        $(this).siblings(".animatecss-2").animate({top:'0'})
         $(this).siblings(".animatecss-2").addClass("dis")
    }) 
    $('.h .four .animatecss-2').on('mouseleave',function(){
       $(this).animate({top:'235'})
        $(this).removeClass("dis")
    })
   $('.h').on('mouseover',function(e){
        e.stopPropagation();        
    })
    $('.h .five img').on('mouseenter',function(){
        $(this).siblings(".animatecss-2").animate({top:'0'})
         $(this).siblings(".animatecss-2").addClass("dis")
    }) 
    $('.h .five .animatecss-2').on('mouseleave',function(){
       $(this).animate({top:'235'})
        $(this).removeClass("dis")
    })




$(".content2 .left .one-left").hover(function(){
    var index = $(this).index();
    $(this).css('background-color','#ffa800')
    $(".content2 .right .one-right").eq(index).css('border','#ffa800 1px solid')
},function(){
    var index = $(this).index();
    $(this).css('background-color','#333333')
    $(".content2 .right .one-right").eq(index).css('border','1px solid #333333')
    $(".content2 .right .one-right").eq(1).css('border-top','none')
    $(".content2 .right .one-right").eq(1).css('border-bottom','none')
})
$(".content2 .right .one-right").hover(function(){
    var index = $(this).index();
    $(this).css('border','#ffa800 1px solid')
    $(".content2 .left .one-left").eq(index).css('background-color','#ffa800')
},function(){
    var index = $(this).index();
    $(this).css('border','#333333 1px solid')
    $(".content2 .left .one-left").eq(index).css('background-color','#333333')
    $(".content2 .right .one-right").eq(1).css('border-top','none')
    $(".content2 .right .one-right").eq(1).css('border-bottom','none')
})
$(".content2 .left .one-left:nth-child(2)").hover(function(){
    $(".content2 .right .one-right").eq(0).css('border-bottom','1px solid #fff')
    $(".content2 .right .one-right").eq(2).css('border-top','1px solid #fff')
},function(){
    $(".content2 .right .one-right").eq(0).css('border','1px solid #333')
    $(".content2 .right .one-right").eq(2).css('border-top','1px solid #333')
})
$(".content2 .right .one-right:nth-child(2)").hover(function(){

    $(".content2 .right .one-right").eq(0).css('border-bottom','1px solid #fff')
    $(".content2 .right .one-right").eq(2).css('border-top','1px solid #fff')
},function(){
    $(".content2 .right .one-right").eq(0).css('border','1px solid #333')
    $(".content2 .right .one-right").eq(2).css('border-top','1px solid #333')
})
