$(function(){
    //IE的兼容
    $(".path2 dl:nth-child(3n)").css("margin-right","0");
    $(".result li:nth-child(3n)").css("margin-right","0");
    $(".p4star .hd li:last-child").css("margin-right","0");
    //Powered by SuperSlide
    jQuery("#p1box_1").slide({mainCell:".bd ul",autoPlay:true});
    jQuery("#p1box_2").slide({mainCell:".bd ul",autoPlay:true});
    jQuery("#p3").slide({mainCell:".bd",effect:"fold"});
    jQuery(".p4star").slide({mainCell:".bd ul",effect:"fold",autoPlay:true});
    jQuery(".per_res").slide({titCell:"h4",targetCell:"div",trigger:"mouseover",effect:"slideDown"});
    jQuery("#p5").slide({mainCell:".bd",autoPlay:false});
    jQuery(".p6cnt").slide({mainCell:".bd",autoPage:true,effect:"top",autoPlay:true,vis:7});

    //P6
    console.log($("#pl_widget_comment"));
    //P7
    $("input").focus(function(){
        $(this).css("background","#ffffff");
    })
    $("input").blur(function(){
        $(this).removeAttr("style");
    });
    $("textarea").focus(function(){
        $(this).css("background","#ffffff");
    })
    $("textarea").blur(function(){
        $(this).removeAttr("style");
    });
})

function lycheck() {
    if (document.feedback.name.value == "" ) {
        alert("请填写您的姓名");
        document.feedback.name.focus();
        return false;
    }

    if (document.feedback.tel.value == "") {
        alert("请填写您的联系方式");
        document.feedback.tel.focus();
        return false;
    }
    if (document.feedback.address.value == "" ) {
        alert("请填写您的地址");
        document.feedback.address.focus();
        return false;
    }
    if (document.feedback.content.value == "" ) {
        alert("请填写您的需求");
        document.feedback.content.focus();
        return false;
    }
};