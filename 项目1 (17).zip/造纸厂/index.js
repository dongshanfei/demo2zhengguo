$(".recommendedBottom ul li").hover(function(e){
	
	$(this).find("span").hide();
	$(this).find("p").show();
},function(e){
	
	$(this).find("span").show();
	$(this).find("p").hide();
})

$(".li5 ul li").hover(function(){
	$(this).find("div").addClass("div1")
},function(){
	$(this).find("div").removeClass("div1")
})

$(".li4 ul li").hover(function(){
	$(this).find("div").show();
},function(){
	$(this).find("div").hide();
})


