// liguoyi 2017.5.26 ������


// section2
$(function(){
	$(".tab1").mouseenter(function(){
		$(this).css('background','#74AB00');
		$(".tab2").css('background','#00A051');
		$(".tab1_text").show();
		$(".tab2_text").hide();
	});
	$(".tab2").mouseenter(function(){
		$(this).css('background','#74AB00');
		$(".tab1").css('background','#00A051');
		$(".tab2_text").show();
		$(".tab1_text").hide();
	})
});
$(function(){
$(".pictures>ul>li").hover(function(){ 
		$(this).children("div").fadeIn(200);
	},
	function(){
		$(this).children("div").fadeOut(200)}
	)
});

//section4
$(function(){
	
	$(".section_4_3_pic>ul>li").hover(function(){
		$(this).children("div").animate({
				"width": "325px",
    "height": "213px",
    "border-radius": "0",
    "top": "0",
    "left": "0",
    "line-height": "213px"
			},200);
	},function(){
		$(this).children("div").animate({
"width": "80px",
    "height": "80px",
    "border-radius": "80px",
    "top": "0",
    "left": "122px",
    "top": "66px",
    "line-height": "80px"
		},200);
	});

	$(".section_4_3_pic>ul>#llli").hover(function(){

		$(".section_4_3_pic>ul>#llli>#dddiv").animate({
				"width": "663px",
    "height": "213px",
    "border-radius": "0",
    "top": "0",
    "left": "0",
    "line-height": "213px"
			},200);
	},function(){
		$(".section_4_3_pic>ul>#llli>#dddiv").animate({
"width": "80px",
    "height": "80px",
    "border-radius": "80px",
    "top": "0",
    "left": "291px",
    "top": "66px",
    "line-height": "80px"
		},200);
	});
});
$(function(){
// 	$("#llli").hover(function(){
// 		$(this).children("div").animate({
// 				"width": "663px",
//     "height": "213px",
//     "border-radius": "0",
//     "top": "0",
//     "left": "0",
//     "line-height": "213px"
// 			},200);
// 	},function(){
// 		$(this).children("div").animate({
// "width": "80px",
//     "height": "80px",
//     "border-radius": "80px",
//     "top": "0",
//     "left": "291px",
//     "top": "66px",
//     "line-height": "80px"
// 		},200);
// 	});

})

$(function(){
	$("#lizuoxiala").hover(function(){
		$("#xialazuo>li").addClass("classbianyanse");
		$("#zuoimg").hide();
		$("#zuoimg2").show();
	},function(){
		$("#xialazuo>li").removeClass("classbianyanse");
		$("#zuoimg").show();
		$("#zuoimg2").hide();
	});

	$("#liyouxiala").hover(function(){
		$("#xialayou>li").addClass("classbianyanse");
		$("#youimg").hide();
		$("#youimg2").show();
	},function(){
		$("#xialayou>li").removeClass("classbianyanse");
		$("#youimg").show();
		$("#youimg2").hide();
	});
});
// section6
$(function(){
	$(".section_6_content>.text1").hover(function(){
		$("#liubian1").css("display","block");
	},function(){
		$("#liubian1").css("display","none");
	});
	$(".section_6_content>.text2").hover(function(){
		$("#liubian2").css("display","block");
	},function(){
		$("#liubian2").css("display","none");
	});
	$(".section_6_content>.text3").hover(function(){
		$("#liubian3").css("display","block");
	},function(){
		$("#liubian3").css("display","none");
	});
	$(".section_6_content>.text4").hover(function(){
		$("#liubian4").css("display","block");
	},function(){
		$("#liubian4").css("display","none");
	});
	$(".section_6_content>.text5").hover(function(){
		$("#liubian5").css("display","block");
	},function(){
		$("#liubian5").css("display","none");
	});
	$(".section_6_content>.text6").hover(function(){
		$("#liubian6").css("display","block");
	},function(){
		$("#liubian6").css("display","none");
	});
});




// section7

$(function(){
	$(".section_7>ul>li").hover(function(){ 
		var index = $(this).index();
		console.log(index)
		$(".section_7>ul>li>div").eq(index).fadeIn();
	},
	function(){var index = $(this).index();
		$(".section_7>ul>li>div").eq(index).fadeOut()}
	);

	$(".li7_8").hover(function(){
		$(".section_7>ul>li>a").css("color","#fff");
	},function(){
		$(".section_7>ul>li>a").css("color","#333");
	});
});

// section9
$(function(){
	$(".sec_9_ul>li").hover(function(){ 
		var index = $(this).index();
		console.log(index)
		$(this).children("div").fadeIn();
	},
	function(){
		$(this).children("div").fadeOut()}
	);
})


