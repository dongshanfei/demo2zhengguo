$(function() {
/*public_header-start*/
$(".navlist li").hover(function(){$(this).find("dl").show();$(this).find(".items").addClass('navah')},function(){$(this).find("dl").hide();$(this).find(".items").removeClass('navah')});$(".sites .wx a").hover(function(){$(".sites .wxbox").slideDown("fast");$(".sites .wx a").css("background-position","-299px -38px")},function(){$(".sites .wxbox").slideUp("fast");$(".sites .wx a").css("background-position","-299px 0")});$(".header_soso a").click(function(){$(".header_soso_con").stop().slideToggle(300)});$(".soso_con_close span").click(function(){$(".header_soso_con").slideUp()});$('.inslt ul li').click(function(){$(this).addClass("bg_hui").siblings().removeClass("bg_hui");var v=$(this).attr('id');var name=$(this).text();$('#classid').val(v)});$(".cebian ul li").eq(0).hover(function(){$(this).find("a").stop().animate({left:'-85px',backgroundColor:'#ff3f3c'},200)},function(){$(this).find("a").stop().animate({left:'0',backgroundColor:'#31353d'},200)});$(".cebian ul li").eq(1).hover(function(){$(this).find("a").stop().animate({left:'-116px',backgroundColor:'#ff3f3c'},200)},function(){$(this).find("a").stop().animate({left:'0',backgroundColor:'#31353d'},200)});$(".cebian ul li").eq(3).hover(function(){$(this).find("a").stop().animate({left:'-132px',backgroundColor:'#ff3f3c'},200)},function(){$(this).find("a").stop().animate({left:'0',backgroundColor:'#31353d'},200)});$(".cebian ul li").hover(function(){$(this).stop().animate({backgroundColor:'#ff3f3c'},200)},function(){$(this).stop().animate({backgroundColor:'#31353d'},200)});$(".cebian ul li").eq(2).hover(function(){$(this).find("div").stop().animate({right:'60px'},300)},function(){$(this).find("div").stop().animate({right:'-60px'},300)});$(".cebian ul li .span5").click(function(){$("html,body").animate({"scrollTop":"0px"})});$(window).scroll(function(){var scrolltop=$("html,body").scrollTop()||$("body").scrollTop();if(scrolltop>$(window).height()/2){$(".cebian ul li").has(".span5").slideDown(500)}else{$(".cebian ul li").has(".span5").slideUp(500)}});
});
$(function() {
    $(".about_ban").mouseover(function() {
        $(".about_ban img").stop().animate({
            bottom: 0
        }, 500)
    });
    $(".video_l div").click(function() {
        if ($(this).hasClass('play')) {
            $(this).removeClass("play");
            $(this).find("video").trigger('play')
        } else {
            $(this).addClass("play");
            $(this).find("video").trigger('pause')
        }
    });
    $(".video_r ul li").click(function() {
        var i = 0;
        var index_t = $(this).index();
        i = index_t;
        $(this).addClass("on").siblings().removeClass("on");
        $(".video_l div").eq(i).show().siblings().hide();
        $(".video_l div").eq(i).find("video").trigger('play');
        $(".video_l div").eq(i).siblings().find("video").trigger('pause')
    });
    $(function() {
        var i = 0;
        var size = $(".about_ry_con ul li").size();
        var y = Math.ceil(size / 3);
        $(".video_r ul").css({
            height: y * 185
        });
        $(".btn_down").click(function() {
            i++;
            move()
        });
        $(".btn_up").click(function() {
            i--;
            move()
        });
        function move() {
            if (i == y) {
                $(".about_ry_con ul").stop().animate({
                    top: 0
                }, 500);
                i = 0
            }
            if (i == -1) {
                $(".about_ry_con ul").stop().animate({
                    top: -(y - 1) * 185
                }, 500);
                i = y - 1
            }
            $(".about_ry_con ul").stop().animate({
                top: -i * 185
            }, 500)
        }
    })
});
$(function() {
    $(window).scroll(function() {
        var n = $(window).scrollTop();
        var m = $("#one").offset().top;
        var b = $("#two").offset().top;
        var v = b - 400;
        var a =$(".video").offset().top-400;
        if(n>a){
            $(this).find("video").trigger('pause');
        }
        if (n > m) {
            $(".bgvid video").trigger('play');
            var t = setInterval(function() {
                $(".bgvid video").trigger('pause').hide();
                $(".bgvid img").show()
            }, 1700)
        } else {
            $(".bgvid video").trigger('pause')
        }
        if (n > v - 300) {
            $(".qianming").animate({}, 300, function() {
                $(".qianming").animate({
                    opacity: '1',
                    left: 18 + "%"
                }, 500)
            })
        }
    })
});
$(function(){
    var func={canvasDraw:function(e,t){function i(){function i(e,t,i){e.save(),e.beginPath(),e.arc(centerX,centerY,70,-Math.PI/2,-Math.PI/2+t*i,!1),e.globalCompositeOperation="source-atop",e.strokeStyle="#ff3f3c",e.lineWidth=10,e.lineCap="round",e.stroke(),e.closePath(),e.restore()}var s=0,n=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||window.msRequestAnimationFrame,a=window.cancelAnimationFrame||window.mozCancelAnimationFrame||window.webkitCancelAnimationFrame||window.msCancelAnimationFrame;n&&a||(n=function(e,t){var i=(new Date).getTime(),n=Math.max(0,16-(i-s)),a=window.setTimeout(function(){e(i+n)},n);return s=i+n,a},a=function(e){window.clearTimeout(e)}),$(e,t).each(function(){function e(){i(f,s,rad),s+=t,o=n(e),s>h&&a(o)}var t=2,s=0,o=null,r=$.trim($(this).data("text")),l=r.split(","),c=l[0],d=l[1],h=parseInt(l[2]),u=this,f=u.getContext("2d");centerX=u.width/2,centerY=u.height/2,rad=2*Math.PI/360,f.save(),f.beginPath(),f.strokeStyle="#eee",f.lineWidth=10,f.arc(centerX,centerY,70,0,2*Math.PI,!1),f.stroke(),f.closePath(),f.textAlign="center",f.textBaseline="middle",f.fillStyle="#ff3f3c",f.font="20px 微软雅黑",f.fillText(c,centerX,centerY),f.fillStyle="#eee",f.font="20px 微软雅黑",f.fillText(d,centerX,centerY+30),f.restore(),n(e)})}var s=$(window),n=(7.5*s.height(),$("#lingyu"));s.on("scroll",function(){!$(this).data("draw")&&s.scrollTop()>=7.5*n.outerHeight()&&(i(),$(this).data("draw",new Date))})},checkSelector:function(e){return $(e).length>0},getFunc:function(){var e=this;return funDir={canvasDraw:{s:".degree canvas",f:e.canvasDraw,p:["canvas",".degree"]}}}};$.each(func.getFunc(),function(){func.checkSelector(this.s)&&(this.p?this.f.apply(this,this.p):this.f())}),function(e){function t(t,s){this.elem=t,this.settings=e.extend(!0,i,s||{}),this.selector=this.settings.selector,this.index=this.settings.index,this.listLen=this.sEk(),this.listHeight=this.sEj(),this.duration=this.settings.duration,this.loop=this.settings.loop,this.autoTimer=null,this.canScroll=!0}e.fn.scrollList=function(i){return this.each(function(){var s=e(this).data("scrollList");s||(s=new t(this,i),e(this).data("scrollList",s)),s.sEa()})}}(jQuery);
});