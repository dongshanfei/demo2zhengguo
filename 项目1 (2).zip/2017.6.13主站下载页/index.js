//流化床资料下面的指哪显示哪效果
var time;
$(".container_1 .firstul ul li").hover(function(){
    var index = $(this).index()
    $(".container_1 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_1 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    $(".container_1 .div1").eq(index).show().siblings(".div1").hide();   
},function(){
    var index = $(this).index()
    $(".container_1 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_1 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    clearTimeout(time);
    time = setTimeout(function() {
        $(".container_1 .div1").eq(index).hide(); 
    },1000);
})
$(".container_1 .div1").hover(function() {
    clearTimeout(time);
},function(){
    $(".container_1 .div1").hide();
})

$(".container_1 .xunhuan").on('click',function(){
    $(".container_1 .firstul").slideToggle();
    if($(".container_1 .xunhuan .imgjiantou").hasClass("imgjiantou")){
        $(".container_1 .xunhuan .imgjiantou").removeClass("imgjiantou").addClass("rotate")
    }
    else{
         $(".container_1 .xunhuan .rotate").removeClass("rotate").addClass("imgjiantou")
    } 

})

// .container_1 .tab1 ul li
$(".container_1 .tab1 ul li").hover(function(e){
    var e =e || event;
    e.stopPropagation(); //阻止冒泡
    e.preventDefault();  //阻止默认行为
    var index = $(this).index();
    // console.log(index)
    $(this).find(".one").css('background-color','#ff3f3c')
    $(this).find("span").css('color','#ff3f3c')
 
},function(){
     $(this).find(".one").css('background-color','#d9d9d9')
     $(this).find(".sp1").css('color','#666')
})


// <!-- 燃油燃气锅炉资料 -->
var time;
$(".container_2 .firstul ul li").hover(function(){
    var index = $(this).index()
    $(".container_2 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_2 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    $(".container_2 .div1").eq(index).show().siblings(".div1").hide();   
},function(){
    var index = $(this).index()
    $(".container_2 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_2 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    clearTimeout(time);
    time = setTimeout(function() {
        $(".container_2 .div1").eq(index).hide(); 
    },2000);
})
$(".container_2 .div1").hover(function() {
    clearTimeout(time);
},function(){
    $(".container_2 .div1").hide();
})

$(".container_2 .xunhuan").on('click',function(){
    $(".container_2 .firstul").slideToggle();
     if($(".container_2 .xunhuan .imgjiantou").hasClass("imgjiantou")){
        $(".container_2 .xunhuan .imgjiantou").removeClass("imgjiantou").addClass("rotate1")
    }
    else{
         $(".container_2 .xunhuan .rotate1").removeClass("rotate1").addClass("imgjiantou")
    } 
})

// .container_2 .tab1 ul li
$(".container_2 .tab1 ul li").hover(function(e){
    var e =e || event;
    e.stopPropagation(); //阻止冒泡
    e.preventDefault();  //阻止默认行为
    var index = $(this).index();
    // console.log(index)
    $(this).find(".one").css('background-color','#ff3f3c')
    $(this).find("span").css('color','#ff3f3c')
 
},function(){
      $(this).find(".one").css('background-color','#d9d9d9')
     $(this).find(".sp1").css('color','#666')
})

// <!-- 生物质锅炉资料 -->
var time;
$(".container_3 .firstul ul li").hover(function(){
    var index = $(this).index()
    $(".container_3 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_3 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    $(".container_3 .div1").eq(index).show().siblings(".div1").hide();   
},function(){
    var index = $(this).index()
    $(".container_3 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_3 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    clearTimeout(time);
    time = setTimeout(function() {
        $(".container_3 .div1").eq(index).hide(); 
    },100);
})
$(".container_3 .div1").hover(function() {
    clearTimeout(time);
},function(){
    $(".container_3 .div1").hide();
})

$(".container_3 .xunhuan").on('click',function(){
    $(".container_3 .firstul").slideToggle();
     if($(".container_3 .xunhuan .imgjiantou").hasClass("imgjiantou")){
        $(".container_3 .xunhuan .imgjiantou").removeClass("imgjiantou").addClass("rotate1")
    }
    else{
         $(".container_3 .xunhuan .rotate1").removeClass("rotate1").addClass("imgjiantou")
    } 
})

// .container_3 .tab1 ul li
$(".container_3 .tab1 ul li").hover(function(e){
    var e =e || event;
    e.stopPropagation(); //阻止冒泡
    e.preventDefault();  //阻止默认行为
    var index = $(this).index();
    // console.log(index)
    $(this).find(".one").css('background-color','#ff3f3c')
    $(this).find("span").css('color','#ff3f3c')
 
},function(){
      $(this).find(".one").css('background-color','#d9d9d9')
     $(this).find(".sp1").css('color','#666')
})

// <!-- 链条炉排锅炉资料 -->
var time;
$(".container_4 .firstul ul li").hover(function(){
    var index = $(this).index()
    $(".container_4 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_4 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    $(".container_4 .div1").eq(index).show().siblings(".div1").hide();   
},function(){
    var index = $(this).index()
    $(".container_4 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_4 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    clearTimeout(time);
    time = setTimeout(function() {
        $(".container_4 .div1").eq(index).hide(); 
    },2000);
})
$(".container_4 .div1").hover(function() {
    clearTimeout(time);
},function(){
    $(".container_4 .div1").hide();
})

$(".container_4 .xunhuan").on('click',function(){
    $(".container_4 .firstul").slideToggle();
     if($(".container_4 .xunhuan .imgjiantou").hasClass("imgjiantou")){
        $(".container_4 .xunhuan .imgjiantou").removeClass("imgjiantou").addClass("rotate1")
    }
    else{
         $(".container_4 .xunhuan .rotate1").removeClass("rotate1").addClass("imgjiantou")
    } 
})

// .container_4 .tab1 ul li
$(".container_4 .tab1 ul li").hover(function(e){
    var e =e || event;
    e.stopPropagation(); //阻止冒泡
    e.preventDefault();  //阻止默认行为
    var index = $(this).index();
    // console.log(index)
    $(this).find(".one").css('background-color','#ff3f3c')
    $(this).find("span").css('color','#ff3f3c')
 
},function(){
     $(this).find(".one").css('background-color','#d9d9d9')
     $(this).find(".sp1").css('color','#666')
})

// <!-- 余热锅炉资料 -->
var time;
$(".container_5 .firstul ul li").hover(function(){
    var index = $(this).index()
    $(".container_5 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_5 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    $(".container_5 .div1").eq(index).show().siblings(".div1").hide();   
},function(){
    var index = $(this).index()
    $(".container_5 .firstul ul li").eq(index).css('background-color','#ff3f3c').siblings().css('background-color','white')
    $(".container_5 .firstul ul li").eq(index).css('color','white').siblings().css('color','#666666')
    clearTimeout(time);
    time = setTimeout(function() {
        $(".container_5 .div1").eq(index).hide(); 
    },2000);
})
$(".container_5 .div1").hover(function() {
    clearTimeout(time);
},function(){
    $(".container_5 .div1").hide();
})

$(".container_5 .xunhuan").on('click',function(){
    $(".container_5 .firstul").slideToggle();
     if($(".container_5 .xunhuan .imgjiantou").hasClass("imgjiantou")){
        $(".container_5 .xunhuan .imgjiantou").removeClass("imgjiantou").addClass("rotate1")
    }
    else{
         $(".container_5 .xunhuan .rotate1").removeClass("rotate1").addClass("imgjiantou")
    } 
})

// .container_5 .tab1 ul li
$(".container_5 .tab1 ul li").hover(function(e){
    var e =e || event;
    e.stopPropagation(); //阻止冒泡
    e.preventDefault();  //阻止默认行为
    var index = $(this).index();
    // console.log(index)
    $(this).find(".one").css('background-color','#ff3f3c')
    $(this).find("span").css('color','#ff3f3c')
 
},function(){
     $(this).find(".one").css('background-color','#d9d9d9')
     $(this).find(".sp1").css('color','#666')
})

// 地图
// 下面是表格
//实用工具下面的tab切换
$(".container .calculatorAll ul li").click(function(){
    var index = $(this).index();
      $(".container .calculatorAll ul li").eq(index).addClass("a").siblings().removeClass('a');
     $(".container .calculatorAll ul li").find("h5").removeClass("b");
    $(".container .calculatorAll ul li").find("h6").removeClass("b");
    $(".container .calculatorAll ul li").eq(index).find("h5").addClass("b");
    $(".container .calculatorAll ul li").eq(index).find("h6").addClass("b");

    $(".container .li-tab").eq(index).addClass("show").siblings().removeClass("show");

  
})
///*热量单位转换,锅炉热量单位换算工具*/
$().ready(function(){
    $(".container .li-tab .btn1").click(function(){
         if($("#in0").val()){
            $("#in1").val(Number($("#in0").val())/60)
            $("#in2").val(Number($("#in0").val())*70/6);
            $("#in3").val(Number($("#in0").val())*0.7/60);
            $("#in4").val(Number($("#in0").val())*42000);
            $("#in5").val(Number($("#in0").val())*1186.322);
            $("#in6").val(Number($("#in0").val())*39685.276);
            } else if($("#in1").val()){
                    $("#in0").val(Number($("#in1").val())*60);
                    $("#in2").val(Number($("#in1").val())*700);
                    $("#in3").val(Number($("#in1").val())*0.7);
                    $("#in4").val(Number($("#in1").val())*700*3600);
                    $("#in5").val(Number($("#in1").val())*1186.322);
                    $("#in6").val(Number($("#in1").val())*39685.276);
                    }else if($("#in2").val()){
                        $("#in0").val(Number($("#in2").val())*60);
                        $("#in1").val(Number($("#in2").val())*700);
                        $("#in3").val(Number($("#in2").val())*0.7);
                        $("#in4").val(Number($("#in2").val())*700*3600);
                        $("#in5").val(Number($("#in2").val())*1186.322);
                        $("#in6").val(Number($("#in2").val())*39685.276);
                    }else if($("#in3").val()){
                        $("#in0").val(Number($("#in3").val())*60/0.7);
                        $("#in1").val(Number($("#in3").val())/0.7);
                        $("#in2").val(Number($("#in3").val())*1000);
                        $("#in4").val(Number($("#in3").val())*3600000);
                        $("#in5").val(Number($("#in3").val())*102000.000);
                        $("#in6").val(Number($("#in3").val())*3412140.000);
                        }else if($("#in4").val()){
                                    $("#in0").val(Number($("#in4").val())/42000);
                                    $("#in1").val(Number($("#in4").val())/2520000);
                                    $("#in2").val(Number($("#in4").val())/3600);
                                    $("#in3").val(Number($("#in4").val())/3600000);
                                    $("#in5").val(Number($("#in4").val())*0.0283);
                                    $("#in6").val(Number($("#in4").val())*0.948);
                                    }  else if($("#in5").val()){
                                            $("#in0").val(Number($("#in5").val())*0.000843);
                                            $("#in1").val(Number($("#in5").val())*0.0000130);
                                            $("#in2").val(Number($("#in5").val())*0.00980);
                                            $("#in3").val(Number($("#in5").val())*0.00000980);
                                            $("#in4").val(Number($("#in5").val())*35.294);
                                            $("#in6").val(Number($("#in5").val())*33.452);
                                            } else if($("#in6").val()){
                                                        $("#in0").val(Number($("#in6").val())*0.0000252);
                                                        $("#in1").val(Number($("#in6").val())*3.90e-7);
                                                        $("#in2").val(Number($("#in6").val())*0.000293);
                                                        $("#in3").val(Number($("#in6").val())*2.93e-7);
                                                        $("#in4").val(Number($("#in6").val())*1.055);
                                                        $("#in5").val(Number($("#in6").val())*0.0299);
                                                        }
    });
    $(".container .li-tab .btn2").click(function(){
        console.log("1")
        $(this).parents(".huansuanAll").siblings("ul").find("input").val("");
    })
})


       
       

 var data = {
                    "quanguo":{"index":"35","stateInitColor":"2","b":"河南.doc"},

                    "shandong":{"index":"14","stateInitColor":"2","b":"山东省.doc"},
                    "jiangsu":{"index":"1","stateInitColor":"0","b":"江苏省.pdf"},
                    "anhui":{"index":"3","stateInitColor":"0","b":"安徽省.pdf"},
                    "zhejiang":{"index":"4","stateInitColor":"0","b":"浙江省.pdf"},
                    "fujian":{"index":"17","stateInitColor":"3","b":"福建省.pdf"},
                    "shanghai":{"index":"9","stateInitColor":"1","b":"上海市.pdf"},

                    "guangdong":{"index":"15","stateInitColor":"2","b":"广东省.doc"},
                    "guangxi":{"index":"10","stateInitColor":"1","b":"广西省.pdf"},
                    "hainan":{"index":"19","stateInitColor":"3","b":"海南省.pdf"},

                    "hubei":{"index":"7","stateInitColor":"1","b":"湖北省.pdf"},
                    "hunan":{"index":"13","stateInitColor":"2","b":"湖南省.pdf"},
                    "henan":{"index":"2","stateInitColor":"0","b":"河南省.pdf"},
                    "jiangxi":{"index":"16","stateInitColor":"3","b":"江西省.pdf"},


                    "beijing":{"index":"6","stateInitColor":"1","b":"北京市.pdf"},
                    "tianjin":{"index":"23","stateInitColor":"4","b":"天津市.doc"},
                    "hebei":{"index":"21","stateInitColor":"4","b":"河北省.pdf"},
                    "shanxi":{"index":"20","stateInitColor":"3","b":"山西.pdf"},
                    "neimongol":{"index":"22","stateInitColor":"4","b":"内蒙古.pdf"},

                    "ningxia":{"index":"31","stateInitColor":"7","b":"宁夏.pdf"},
                    "xinjiang":{"index":"32","stateInitColor":"7","b":"新疆.pdf"},
                    "qinghai":{"index":"29","stateInitColor":"7","b":"青海省.pdf"},
                    "shaanxi":{"index":"25","stateInitColor":"4","b":"陕西.pdf"},
                    "gansu":{"index":"24","stateInitColor":"4","b":"甘肃省.pdf"},

                    "sichuan":{"index":"11","stateInitColor":"2","b":"四川省.pdf"},
                    "guizhou":{"index":"12","stateInitColor":"2","b":"贵州省.pdf"},
                    "yunnan":{"index":"18","stateInitColor":"3","b":"云南省.pdf"},   
                    "xizang":{"index":"30","stateInitColor":"7","b":"西藏.pdf"},   
                    "chongqing":{"index":"34","stateInitColor":"7","b":"重庆.pdf"},

                    "liaoning":{"index":"5","stateInitColor":"0","b":"辽宁省.pdf"},
                    "jilin":{"index":"8","stateInitColor":"1","b":"吉林省.pdf"},
                    "heilongjiang":{"index":"33","stateInitColor":"7","b":"黑龙江.pdf"},
                    "macau":{"index":"26","stateInitColor":"7","b":""},
                    "hongkong":{"index":"27","stateInitColor":"7","b":""},
                    "taiwan":{"index":"28","stateInitColor":"7","b":""},
                                       
                                           
                    
    };
    var i = 1;
    for (k in data) {
        if (i <= 1) {
            
            $('#MapControl .list0').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i class="' + _cls + '">' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }         
        else if (i <= 7) {
            var _cls = i < 4 ? 'active' : '';
            $('#MapControl .list1').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i class="' + _cls + '">' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        } 
        else if (i <= 10) {
            $('#MapControl .list2').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        } 
        else if (i <= 14) {
            $('#MapControl .list3').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }
        else if (i <= 19) {
            $('#MapControl .list4').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }
        else if (i <= 24) {
            $('#MapControl .list5').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }
        else if (i <= 29) {
            $('#MapControl .list6').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }
        else if (i <= 32) {
            $('#MapControl .list7').append('<li name="' + k + '"><a href="'+data[k].b+'" download><div class="mapInfo"><i>' + (i++) + '</i><span>' + chinaMapConfig.names[k] + '</span></div></a></li>')
        }
    }
    var mapObj_1 = {};
    var stateColorList = ['003399', '0058B0', '0071E1', '1C8DFF', '51A8FF', '82C0FF', 'AAD5FF','AAD5FF'];
    $('#RegionMap').SVGMap({
        external: mapObj_1,
        mapName: 'china',
        mapWidth: 560,
        mapHeight: 470,
        stateData: data,
        stateTipHtml: function(mapData, obj) {
            // var _value = mapData[obj.id].value;
            // var _idx = mapData[obj.id].index;
            // var active = '';
            // _idx < 4 ? active = 'active' : active = '';
            var tipStr = '<div class="mapInfo"><span>' + obj.name + '</span></div>';
            return tipStr
        }
    });
    $('#MapControl li').hover(function() {
        var index = $(this).index();
        var thisName = $(this).attr('name');
        var thisHtml = $(this).html();
        $('#MapControl li').removeClass('select');
        $(this).addClass('select');
        $(document.body).append('<div id="StateTip"></div');
        $('#StateTip').css({
            left: $(mapObj_1[thisName].node).offset().left - 50,
            top: $(mapObj_1[thisName].node).offset().top - 40
        }).html(thisHtml).show();
        mapObj_1[thisName].attr({ fill: '#ff3f3c'})
        $(".regionList ul li i").hide();//这是我自己加上去的
    }, function() {
        var thisName = $(this).attr('name');
        $('#StateTip').remove();
        $('#MapControl li').removeClass('select');
        // mapObj_1[$(this).attr('name')].attr({ fill: "#" + stateColorList[data[$(this).attr('name')].stateInitColor] })
        mapObj_1[$(this).attr('name')].attr({ fill: '#e6e6e6'})
    });
    $('#MapColor').show();




//这下面是计算器
var kindd = "";
var valuee = 0;

function isIE() {
    return ("ActiveXObject" in window)
}
function clear() {
    var obj = document.getElementsByName("result");
    while (obj.length > 0) {
        if (isIE()) {
            obj[0].parentNode.removeNode(true)
        } else {
            obj[0].parentNode.remove()
        }
    }
};

function isNum(value) {
    if (value.match(/^[0-9]\d*(\.\d+)?$/)) {
        return true
    }
    alert("请输入规范的数值(大于等于0)");
    return false
};

function isRight(value, value1, value2) {
    if (value.match(/^[0-9]\d*(\.\d+)?$/) && value >= value1 && value <= value2) {
        return true
    }
    alert("请输入介于" + value1 + "~" + value2 + "之间的数");
    return false
};

function setli(name, cursel) {
    clear();
    var input = document.getElementsByTagName("input");
    for (var i = 0; i < input.length; i++) {
        input[i].value = 0
    };
    for (var i = 1; i <= document.getElementById("tb1").getElementsByTagName("li").length; i++) {
        var menu = document.getElementById(name + i);
        var menudiv = document.getElementById("con_" + name + "_" + i);
        if (i == cursel) {
            menu.className = "off";
            menudiv.style.display = "block"
        } else {
            menu.className = "";
            menudiv.style.display = "none"
        }
    }
    var div = document.getElementById("kin_" + kindd + "_" + valuee);
    if (div != null) {
        div.style.display = "none"
    }
};

function show(kind, value) {
    kindd = kind;
    valuee = value;
    clear();
    for (var i = 1; i <= document.getElementById("tb1").getElementsByTagName("a").length; i++) {
        var div = document.getElementById("kin_" + kind + "_" + i);
        if (i == value) {
            div.style.display = "block";
            if (kind == "seven" && value == "1") {
                document.getElementById("input_seven_1_5").value = "92"
            }
            if (kind == "seven" && value == "2") {
                document.getElementById("input_seven_2_6").value = "90"
            }
            if (kind == "nine" && value == "1") {
                document.getElementById("input_nine_1_4").value = "1.15"
            }
        } else {
            div.style.display = "none"
        }
    }
};

function result(value) {
    return value > 1 ? value.toFixed(3) : value.toPrecision(3)
};

function change(value) {
    if (value == "5") {
        document.getElementById("input_seven_2_6").value = "98";
        document.getElementById("input_seven_1_5").value = "98"
    } else {
        document.getElementById("input_seven_2_6").value = "90";
        document.getElementById("input_seven_1_5").value = "92"
    }
};
var a = 0;
var b = 0;
var c = 0;
var d = 0;
var e = 0;
var f = 0;
var g = 0;
var h = 0;
var i = 0;
var j = 0;
var k = 0;
var add = document.getElementById("table_one_1");
var rows = 0;

function resultONE1() {
    clear();
    a = document.getElementById("input_one_1_1").value;
    b = document.getElementById("input_one_1_2").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_one_1");
    rows = add.rows.length;
    switch (b) {
    case "0":
        return alert("请选择单位");
        break;
    case "1":
        result1 = result(a * 0.08598);
        add.insertRow(rows).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * 0.001);
        add.insertRow(rows + 1).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * 0.00133);
        add.insertRow(rows + 2).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * 3412.14);
        add.insertRow(rows + 3).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * 3600);
        add.insertRow(rows + 4).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        result1 = result(a * 102);
        add.insertRow(rows + 5).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "2":
        result1 = result(a * (1 / 0.08598));
        add.insertRow(rows).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 0.08598) * 0.001);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * (1 / 0.08598) * 0.00133);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * (1 / 0.08598) * 3412.14);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * (1 / 0.08598) * 3600);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        result1 = result(a * (1 / 0.08598) * 102);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "3":
        result1 = result(a * (1 / 0.001));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 0.001) * 0.08598);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * (1 / 0.001) * 0.00133);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * (1 / 0.001) * 3412.14);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * (1 / 0.001) * 3600);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        result1 = result(a * (1 / 0.001) * 102);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "4":
        result1 = result(a * (1 / 0.00133));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 0.00133) * 0.08598);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * (1 / 0.00133) * 0.001);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * (1 / 0.00133) * 3412.14);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * (1 / 0.00133) * 3600);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        result1 = result(a * (1 / 0.00133) * 102);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "5":
        result1 = result(a * (1 / 3412.14));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 3412.14) * 0.08598);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * (1 / 3412.14) * 0.001);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * (1 / 3412.14) * 0.00133);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * (1 / 3412.14) * 3600);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        result1 = result(a * (1 / 3412.14) * 102);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "6":
        result1 = result(a * (1 / 3600));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 3600) * 0.08598);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * (1 / 3600) * 0.001);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * (1 / 3600) * 0.00133);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * (1 / 3600) * 3412.14);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * (1 / 3600) * 102);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力.米/秒(kgf.m/s)</td>";
        break;
    case "7":
        result1 = result(a * (1 / 102));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千瓦(kw)</td>";
        result1 = result(a * (1 / 102) * 0.08598);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "万大卡(104kcal/h)</td>";
        result1 = result(a * (1 / 102) * 0.001);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆瓦(MW)</td>";
        result1 = result(a * (1 / 102) * 0.00133);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "蒸吨/时(t/h)</td>";
        result1 = result(a * (1 / 102) * 3412.14);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "英热/时(Btu/h)</td>";
        result1 = result(a * (1 / 102) * 3600);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千焦/时(kj/h)</td>";
        break
    };
    add.insertRow(rows++).innerHTML = "<td name='result'>注：蒸汽折算吨位按20℃给水、1.25MPa 饱和蒸汽热量核算</td>"
};

function resultONE2() {
    clear();
    a = document.getElementById("input_one_2_1").value;
    b = document.getElementById("input_one_2_2").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_one_2");
    rows = add.rows.length;
    switch (b) {
    case "1":
        result1 = result(a * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "2":
        result1 = result(a * (1 / 10.197));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 10.197) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 10.197) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 10.197) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 10.197) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 10.197) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 10.197) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 10.197) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 10.197) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 10.197) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "3":
        result1 = result(a * (1 / 1000));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 1000) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 1000) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 1000) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 1000) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 1000) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 1000) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 1000) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 1000) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 1000) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "4":
        result1 = result(a * (1 / 1000000));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 1000000) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 1000000) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 1000000) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 1000000) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 1000000) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 1000000) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 1000000) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 1000000) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 1000000) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "5":
        result1 = result(a * (1 / 1000000));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 1000000) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 1000000) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 1000000) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 1000000) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 1000000) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 1000000) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 1000000) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 1000000) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 1000000) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "6":
        result1 = result(a * (1 / 7507.2));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 7507.2) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 7507.2) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 7507.2) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 7507.2) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 7507.2) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 7507.2) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 7507.2) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 7507.2) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 7507.2) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "7":
        result1 = result(a * (1 / 101.97));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 101.97) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 101.97) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 101.97) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 101.97) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 101.97) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 101.97) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 101.97) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 101.97) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 101.97) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        result1 = result();
        break;
    case "8":
        result1 = result(a * (1 / 9.8692));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 9.8692) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 9.8692) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 9.8692) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 9.8692) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 9.8692) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 9.8692) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 9.8692) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 9.8692) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 9.8692) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "9":
        result1 = result(a * (1 / 10));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 10) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 10) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 10) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 10) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 10) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 10) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 10) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 10) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        result1 = result(a * (1 / 10) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "10":
        result1 = result(a * (1 / 7500.6));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 7500.6) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 7500.6) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 7500.6) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 7500.6) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 7500.6) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 7500.6) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 7500.6) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 7500.6) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 7500.6) * 14.504);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "磅每平方英寸(psi)</td>";
        break;
    case "11":
        result1 = result(a * (1 / 14.504));
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "兆帕(MPa)</td>";
        result1 = result(a * (1 / 14.504) * 10.197);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "公斤力/立方厘米(kgf/cm3)</td>";
        result1 = result(a * (1 / 14.504) * 1000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "千帕(KPa)</td>";
        result1 = result(a * (1 / 14.504) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "帕斯卡(Pa)</td>";
        result1 = result(a * (1 / 14.504) * 1000000);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "牛顿每平米(N/m2)</td>";
        result1 = result(a * (1 / 14.504) * 7507.2);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "毫米汞柱(mmHg)</td>";
        result1 = result(a * (1 / 14.504) * 101.97);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "米水柱(mH2O)</td>";
        result1 = result(a * (1 / 14.504) * 9.8692);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "大气压(atm)</td>";
        result1 = result(a * (1 / 14.504) * 10);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "巴(bar)</td>";
        result1 = result(a * (1 / 14.504) * 7500.6);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "托(Torr)</td>";
        break
    }
};

function resultONE3() {
    clear();
    a = document.getElementById("input_one_3_1").value;
    b = document.getElementById("input_one_3_2").value;
    if (a < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    add = document.getElementById("table_one_3");
    rows = add.rows.length;
    switch (b) {
    case "1":
        result1 = result(a * 9 / 5 + 32);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "华氏温度(℉)</td>";
        result1 = result(a * 1 + 273.15);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "开尔文温度(K)</td>";
        break;
    case "2":
        result1 = result((a * 1 - 32) * 5 / 9);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "摄氏温度(℃)</td>";
        result1 = result((a * 1 - 32) * 5 / 9 + 273.15 * 1);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "开尔文温度(K)</td>";
        break;
    case "3":
        result1 = result(a * 1 - 273.15 * 1);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "摄氏温度(℃)</td>";
        result1 = result((a * 1 - 273.15 * 1) * 9 / 5 + 32);
        add.insertRow(rows++).innerHTML = "<td name='result'>" + result1 + "华氏温度(℉)</td>";
        break
    }
};
var result1 = 0;
var result2 = 0;
var result3 = 0;
var result4 = 0;

function resultTWO1() {
    clear();
    a = document.getElementById("input_two_1_1").value;
    b = document.getElementById("input_two_1_2").value;
    if (!isNum(a)) return;
    if (!isRight(b, 0, 100)) return;
    if (b) add = document.getElementById("table_two_1");
    rows = add.rows.length;
    if (a >= 5) {
        result1 = a * 70 * (1 + b / 100);
        add.insertRow(rows++).innerHTML = "<td name='result'>采暖负荷" + result1.toFixed(3) + "(KW)</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1.toFixed(3) + ",'table_two_1')>炉型推荐</a></td>"
    } else if (a >= 2.5 && a < 5) {
        result1 = a * (130 - 12 * a) * (1 + b / 100);
        add.insertRow(rows++).innerHTML = "<td name='result'>采暖负荷" + result1.toFixed(3) + "(KW)</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1.toFixed(3) + ",'table_two_1')>炉型推荐</a></td>"
    } else if (a < 2.5 && a >= 0) {
        result1 = a * 100 * (1 + b / 100);
        add.insertRow(rows++).innerHTML = "<td name='result'>采暖负荷" + result1.toFixed(3) + "(KW)</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1.toFixed(3) + ",'table_two_1')>炉型推荐</a></td>"
    }
};

function resultTWO2() {
    clear();
    a = document.getElementById("input_two_2_1").value;
    b = document.getElementById("input_two_2_2").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_two_2");
    rows = add.rows.length;
    if (b == 0) alert("请选择应用场合");
    result1 = a * b;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>生活用水负荷" + result1 + "(KW)</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1 + ",'table_two_2')>炉型推荐</a></td>"
};

function resultTWO3() {
    clear();
    a = document.getElementById("input_two_3_1").value;
    b = document.getElementById("input_two_3_2").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_two_3");
    rows = add.rows.length;
    result1 = a * b * 0.7;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>泳池生活热水负荷" + result1 + "(KW)</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1 + ",'table_two_3')>炉型推荐</a></td>"
};

function resultTWO4() {
    clear();
    a = document.getElementById("input_two_4_1").value;
    b = document.getElementById("input_two_4_2").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    add = document.getElementById("table_two_4");
    rows = add.rows.length;
    result1 = 58 * b + a * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>浴室热水负荷" + result1 + "(KW)</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestTWO(" + result1 + ",'table_two_4')>炉型推荐</a></td>"
};

function resultTWO5() {
    clear();
    a = document.getElementById("input_two_5_1").value;
    b = document.getElementById("input_two_5_2").value;
    c = document.getElementById("input_two_5_3").value;
    d = document.getElementById("input_two_5_4").value;
    e = document.getElementById("input_two_5_5").value;
    f = document.getElementById("input_two_5_6").value;
    g = document.getElementById("input_two_5_7").value;
    h = document.getElementById("input_two_5_8").value;
    if (!isNum(a)) return;
    if (!isRight(b, 0, 100)) return;
    if (!isNum(c)) return;
    if (!isNum(e)) return;
    if (!isNum(g)) return;
    if (!isNum(h)) return;
    add = document.getElementById("table_two_5");
    rows = add.rows.length;
    if (a >= 5) {
        result1 = a * 70 * (1 + b / 100)
    } else if (a >= 2.5 && a < 5) {
        result1 = a * (130 - 12 * a) * (1 + b / 100)
    } else if (a < 2.5 && a >= 0) {
        result1 = a * 100 * (1 + b / 100)
    }
    result2 = c * d;
    result3 = e * f * 0.7;
    result4 = 58 * h + g * 1;
    var result5 = result1 + result2 + result3 + result4;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    result3 = result3 > 1 ? result3.toFixed(3) : result3.toPrecision(3);
    result4 = result4 > 1 ? result4.toFixed(3) : result4.toPrecision(3);
    result5 = result5 > 1 ? result5.toFixed(3) : result5.toPrecision(3);
    if (result5 <= 0) {
        alert("累计总热负荷小于等于0，无法推荐");
        return
    }
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>累计总热负荷" + (result5) + "(KW),</br>其中采暖负荷" + result1 + "KW,</br>生活用水负荷" + (result2) + "KW,</br>泳池生活热水负荷" + result3 + "KW,</br>浴室生活热水负荷" + result4 + "KW</td>";
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'></td>";
    var pj = 0;
    var index = 0;
    var count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>冷凝热水锅炉:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 1400) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.1-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.8-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS3.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS4.2-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS5.6-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS7.0-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS8.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS10.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS14-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>真空热水机组:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 350) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ30-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 350 && pj <= 700) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ60-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 700 && pj <= 1050) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ90-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 3
        } else if (pj > 1050 && pj <= 1400) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ120-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 4
        } else if (pj > 1400 && pj <= 1750) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ180-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 5
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ210-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 6
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ240-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 7
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ300-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 8
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ360-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ480-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ600-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ720-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 13) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ900-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 13
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 14) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ1200-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 14
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>节能热水炉:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 350) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS0.35-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 350 && pj <= 700) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS0.7-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 700 && pj <= 1050) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.05-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 3
        } else if (pj > 1050 && pj <= 1400) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 4
        } else if (pj > 1400 && pj <= 1750) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.75-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 5
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.1-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 6
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.8-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 7
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS3.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 8
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS4.2-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS5.6-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS7.0-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS8.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 13) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS10.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 13
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 14) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS14-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 14
        }
    };
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>注：大型水管锅炉请联系本公司定制，销售电话：0510-86632366。</td>"
};

function resultTHREE1() {
    clear();
    a = document.getElementById("input_three_1_1").value;
    b = document.getElementById("input_three_1_2").value;
    c = document.getElementById("input_three_1_3").value;
    d = document.getElementById("input_three_1_4").value;
    e = document.getElementById("input_three_1_5").value;
    f = document.getElementById("input_three_1_6").value;
    g = document.getElementById("input_three_1_7").value;
    h = document.getElementById("input_three_1_8").value;
    i = document.getElementById("input_three_1_9").value;
    j = document.getElementById("input_three_1_10").value;
    k = document.getElementById("input_three_1_11").value;
    if (!isNum(a)) return;
    if (b < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(c)) return;
    if (!isNum(d)) return;
    if (!isNum(e)) return;
    if (!isNum(f)) return;
    if (!isNum(g)) return;
    if (!isNum(h)) return;
    if (!isNum(i)) return;
    if (!isNum(j)) return;
    if (!isNum(k)) return;
    result1 = (c * e / d * 1000 + 1 + f * 0.2 + g * 1 + h * 0.1) * Math.pow((a / 3600 * (273 + b * 1) / 273 / Math.pow(d / 2000, 2) / Math.PI), 2) / 2 * 273 * 1.25 / (273 + b * 1) + (i * j / k * 1000) * Math.pow((a / 3600 * (273 + b * 1) / 273 / Math.pow((k / 2000), 2) / Math.PI), 2) / 2 * 273 * 1.25 / (273 + b * 1) - 9.8 * j * (1.2 - 1.25 * 273 / (273 + b * 1));
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add = document.getElementById("table_three_1");
    rows = add.rows.length;
    result2 = Math.pow((a * (273 + b * 1) / 273 / 3600 / 15 / Math.PI), 0.5) * 2000;
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    result3 = Math.pow((a * (273 + b * 1) / 273 / 3600 / 5 / Math.PI), 0.5) * 2000;
    result3 = result3 > 1 ? result3.toFixed(3) : result3.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>建议烟道内径" + result2 + "~" + result3 + "mm</td>";
    result2 = Math.pow((a * (273 + b * 1) / 273 / 3600 / 10 / Math.PI), 0.5) * 2000;
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    result3 = Math.pow((a * (273 + b * 1) / 273 / 3600 / 5 / Math.PI), 0.5) * 2000;
    result3 = result3 > 1 ? result3.toFixed(3) : result3.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>建议烟囱内径" + result2 + "~" + result3 + "mm</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>烟气阻力" + result1 + "Pa</td>"
};

function resultTHREE2() {
    clear();
    a = document.getElementById("input_three_2_1").value;
    b = document.getElementById("input_three_2_2").value;
    c = document.getElementById("input_three_2_3").value;
    d = document.getElementById("input_three_2_4").value;
    e = document.getElementById("input_three_2_5").value;
    f = document.getElementById("input_three_2_6").value;
    g = document.getElementById("input_three_2_7").value;
    h = document.getElementById("input_three_2_8").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (!isNum(c)) return;
    if (!isNum(d)) return;
    if (!isNum(e)) return;
    if (!isNum(f)) return;
    if (!isNum(g)) return;
    if (!isNum(h)) return;
    var result1 = 1.10676 * Math.pow(10, 11) * Math.pow(a * 1, 2) * c / Math.pow(b * 1, 16 / 3) / Math.pow(Math.PI, 2) + (1.5 + d * 0.2 + e * 1 + f * 0.2 + 2 * g + h * 4.5) * 500 * Math.pow((1111.1 * a / Math.pow(b * 1, 2) / Math.PI), 2);
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add = document.getElementById("table_three_2");
    rows = add.rows.length;
    add.insertRow(rows++).innerHTML = "<td name='result'>水流阻力" + result1 + "Pa</td>"
};

function resultTHREE3() {
    clear();
    a = document.getElementById("input_three_3_1").value;
    b = document.getElementById("input_three_3_2").value;
    c = document.getElementById("input_three_3_3").value;
    d = document.getElementById("input_three_3_4").value;
    e = document.getElementById("input_three_3_5").value;
    f = document.getElementById("input_three_3_6").value;
    g = document.getElementById("input_three_3_7").value;
    h = document.getElementById("input_three_3_8").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (!isNum(c)) return;
    if (!isNum(d)) return;
    if (!isNum(e)) return;
    if (!isNum(f)) return;
    if (!isNum(g)) return;
    result1 = (h * c / b * 1000 + 1 + d * 0.2 + e * 1 + f * 0.1) * Math.pow((1111.1 * a / Math.pow(b * 1, 2) / Math.PI), 2) / 2 * 273 * 1.293 / (273 + g * 1);
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add = document.getElementById("table_three_3");
    rows = add.rows.length;
    add.insertRow(rows++).innerHTML = "<td name='result'>风道阻力" + result1 + "Pa</td>"
};

function resultFOUR1() {
    clear();
    a = document.getElementById("input_four_1_1").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_four_1");
    rows = add.rows.length;
    result1 = 101.3 - 1.208 * 0.01 * a + 6.113 * Math.pow(10, -7) * Math.pow(a * 1, 2) - 1.695 * Math.pow(10, -11) * Math.pow(a * 1, 3);
    result2 = 100 * 1 - a / 300;
    result3 = 1 * 1 - 1.202 * Math.pow(10, -4) * a + 5.484 * Math.pow(10, -9) * Math.pow(a * 1, 2);
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    result3 = result3 > 1 ? result3.toFixed(3) : result3.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>当地大气压" + (result1) + "KPa,</br>饱和蒸汽温度" + (result2) + "℃,</br>海拔修正系数" + (result3) + "</td>"
};
var Ii = new Array();
var Ji = new Array();
var ni = new Array();
var Jo = new Array();
var no = new Array();

function vz(t, p) {
    Ii = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 7, 7, 7, 8, 8, 9, 10, 10, 10, 16, 16, 18, 20, 20, 20, 21, 22, 23, 24, 24, 24];
    Ji = [0, 1, 2, 3, 6, 1, 2, 4, 7, 36, 0, 1, 3, 6, 35, 1, 2, 3, 7, 3, 16, 35, 0, 11, 25, 8, 36, 13, 4, 10, 14, 29, 50, 57, 20, 35, 48, 21, 53, 39, 26, 40, 58];
    ni = [-1.7731742473213 * Math.pow(10, -3), -0.017834862292358, -0.045996013696365, -0.057581259083432, -0.05032527872793, -3.3032641670203 * Math.pow(10, -5), -1.8948987516315 * Math.pow(10, -4), -3.9392777243355 * Math.pow(10, -3), -0.043797295650573, -2.6674547914087 * Math.pow(10, -5), 2.0481737692309 * Math.pow(10, -8), 4.3870667284435 * Math.pow(10, -7), -3.227767723857 * Math.pow(10, -5), -1.5033924542148 * Math.pow(10, -3), -0.040668253562649, -7.8847309559367 * Math.pow(10, -10), 1.2790717852285 * Math.pow(10, -8), 4.8225372718507 * Math.pow(10, -7), 2.2922076337661 * Math.pow(10, -6), -1.6714766451061 * Math.pow(10, -11), -2.1171472321355 * Math.pow(10, -3), -23.895741934104, -5.905956432427 * Math.pow(10, -18), -1.2621808899101 * Math.pow(10, -6), -0.038946842435739, 1.1256211360459 * Math.pow(10, -11), -8.2311340897998, 1.9809712802088 * Math.pow(10, -8), 1.0406965210174 * Math.pow(10, -19), -1.0234747095929 * Math.pow(10, -13), -1.0018179379511 * Math.pow(10, -9), -8.0882908646985 * Math.pow(10, -11), 0.10693031879409, -0.33662250574171, 8.9185845355421 * Math.pow(10, -25), 3.0629316876232 * Math.pow(10, -13), -4.2002467698208 * Math.pow(10, -6), -5.9056029685639 * Math.pow(10, -26), 3.7826947613457 * Math.pow(10, -6), -1.2768608934681 * Math.pow(10, -15), 7.3087610595061 * Math.pow(10, -29), 5.5414715350778 * Math.pow(10, -17), -9.436970724121 * Math.pow(10, -7)];
    var R = 0.461526;
    var px = 1;
    var Tx = 540;
    var GAMp = 0;
    var Pi = (p * 1 + 0.1013) / px;
    var Tao = Tx / (t * 1 + 273.15);
    var GAMpo = 1 / Pi;
    for (var i = 0; i <= 42; i++) {
        GAMp = GAMp + ni[i] * Ii[i] * Math.pow(Pi, Ii[i] - 1) * Math.pow(Tao - 0.5, Ji[i])
    };
    var vz = (GAMp + GAMpo) * Pi * R * (t * 1 + 273.15) / (p * 1 + 0.1) / 1000;
    return vz
};

function ts(p) {
    var bata = Math.pow(p * 1 + 0.1013, 0.25);
    var ee = Math.pow(bata, 2) - parseFloat(17.073846940092) * bata + parseFloat(14.91510861353);
    var ff = 1167.0521452767 * Math.pow(bata, 2) + 12020.82470247 * bata - 4823.2657361591;
    var gg = -724213.16703206 * Math.pow(bata, 2) - 3232555.0322333 * bata + 405113.40542057;
    var dd = 2 * gg / (-Math.pow(Math.pow(ff, 2) - 4 * ee * gg, 0.5) - ff);
    var ts = (650.17534844798 + dd - Math.pow((Math.pow((650.17534844798 + dd), 2) - 4 * (650.17534844798 * dd - 0.23855557567849)), 0.5)) / 2 - 273.15;
    return ts
};

function ps(t) {
    var sita = t * 1 + 273.15 - parseFloat(0.23855557567849) / parseFloat(t * 1 - parseFloat(650.17534844798) + 273.15);
    var aa = Math.pow(sita, 2) + 1167.0521452767 * sita - 724213.16703206;
    var bb = -17.073846940092 * Math.pow(sita, 2) + 12020.82470247 * sita - 3232555.0322333;
    var cc = 14.91510861353 * Math.pow(sita, 2) - 4823.2657361591 * sita + 405113.40542057;
    var ps = Math.pow((2 * cc / (Math.pow((Math.pow(bb, 2) - 4 * aa * cc), 0.5) - bb)), 4) - 0.1013;
    return ps
};

function hz(t, p) {
    Jo = [0, 1, -5, -4, -3, -2, -1, 2, 3];
    no = [-9.6927686500217, 10.086655968018, -0.005608791128302, 0.071452738081455, -0.40710498223928, 1.4240819171444, -4.383951131945, -0.28408632460772, 0.021268463753307];
    Ii = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 7, 7, 7, 8, 8, 9, 10, 10, 10, 16, 16, 18, 20, 20, 20, 21, 22, 23, 24, 24, 24];
    Ji = [0, 1, 2, 3, 6, 1, 2, 4, 7, 36, 0, 1, 3, 6, 35, 1, 2, 3, 7, 3, 16, 35, 0, 11, 25, 8, 36, 13, 4, 10, 14, 29, 50, 57, 20, 35, 48, 21, 53, 39, 26, 40, 58];
    ni = [-1.7731742473213 * Math.pow(10, -3), -0.017834862292358, -0.045996013696365, -0.057581259083432, -0.05032527872793, -3.3032641670203 * Math.pow(10, -5), -1.8948987516315 * Math.pow(10, -4), -3.9392777243355 * Math.pow(10, -3), -0.043797295650573, -2.6674547914087 * Math.pow(10, -5), 2.0481737692309 * Math.pow(10, -8), 4.3870667284435 * Math.pow(10, -7), -3.227767723857 * Math.pow(10, -5), -1.5033924542148 * Math.pow(10, -3), -0.040668253562649, -7.8847309559367 * Math.pow(10, -10), 1.2790717852285 * Math.pow(10, -8), 4.8225372718507 * Math.pow(10, -7), 2.2922076337661 * Math.pow(10, -6), -1.6714766451061 * Math.pow(10, -11), -2.1171472321355 * Math.pow(10, -3), -23.895741934104, -5.905956432427 * Math.pow(10, -18), -1.2621808899101 * Math.pow(10, -6), -0.038946842435739, 1.1256211360459 * Math.pow(10, -11), -8.2311340897998, 1.9809712802088 * Math.pow(10, -8), 1.0406965210174 * Math.pow(10, -19), -1.0234747095929 * Math.pow(10, -13), -1.0018179379511 * Math.pow(10, -9), -8.0882908646985 * Math.pow(10, -11), 0.10693031879409, -0.33662250574171, 8.9185845355421 * Math.pow(10, -25), 3.0629316876232 * Math.pow(10, -13), -4.2002467698208 * Math.pow(10, -6), -5.9056029685639 * Math.pow(10, -26), 3.7826947613457 * Math.pow(10, -6), -1.2768608934681 * Math.pow(10, -15), 7.3087610595061 * Math.pow(10, -29), 5.5414715350778 * Math.pow(10, -17), -9.436970724121 * Math.pow(10, -7)];
    var R = 0.461526;
    var px = 1;
    var Tx = 540;
    var GAMt = 0;
    var GAMto = 0;
    var Pi = (p * 1 + 0.1013) / px;
    var Tao = Tx / (t * 1 + 273.15);
    for (var i = 0; i <= 8; i++) {
        GAMto = GAMto * 1 + no[i] * Jo[i] * Math.pow(Tao, Jo[i] - 1)
    };
    for (var i = 0; i <= 42; i++) {
        GAMt = GAMt + ni[i] * Ji[i] * Math.pow(Pi, Ii[i]) * Math.pow(Tao - 0.5, Ji[i] - 1)
    };
    var hz = (GAMt + GAMto) * Tao * R * (t * 1 + 273.15);
    return hz
};

function hs(t, p) {
    ni = [0.14632971213167, -0.84548187169114, -3.756360367204, 3.3855169168385, -0.95791963387872, 0.15772038513228, -0.016616417199501, 8.1214629983568 * Math.pow(10, -4), 2.8319080123804 * Math.pow(10, -4), -6.0706301565874 * Math.pow(10, -4), -0.018990068218419, -0.032529748770505, -0.021841717175414, -5.283835796993 * Math.pow(10, -5), -4.7184321073267 * Math.pow(10, -4), -3.0001780793026 * Math.pow(10, -4), 4.7661393906987 * Math.pow(10, -5), -4.4141845330846 * Math.pow(10, -6), -7.2694996297594 * Math.pow(10, -16), -3.1679644845054 * Math.pow(10, -5), -2.8270797985312 * Math.pow(10, -6), -8.5205128120103 * Math.pow(10, -10), -2.2425281908 * Math.pow(10, -6), -6.5171222895601 * Math.pow(10, -7), -1.4341729937924 * Math.pow(10, -13), -4.0516996860117 * Math.pow(10, -7), -1.2734301741641 * Math.pow(10, -9), -1.7424871230634 * Math.pow(10, -10), -6.8762131295531 * Math.pow(10, -19), 1.4478307828521 * Math.pow(10, -20), 2.6335781662795 * Math.pow(10, -23), -1.1947622640071 * Math.pow(10, -23), 1.8228094581404 * Math.pow(10, -24), -9.3537087292458 * Math.pow(10, -26)];
    Ii = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 8, 8, 21, 23, 29, 30, 31, 32];
    Ji = [-2, -1, 0, 1, 2, 3, 4, 5, -9, -7, -1, 0, 1, 3, -3, 0, 1, 3, 17, -4, 0, 6, -5, -2, 10, -8, -11, -6, -29, -31, -38, -39, -40, -41];
    var R = 0.461526;
    var px = 16.53;
    var Tx = 1386;
    var GAMt = 0;
    var Pi = (p * 1 + 0.1013) / px;
    var Tao = Tx / (t * 1 + 273.15);
    for (var i = 0; i <= 33; i++) {
        GAMt = GAMt * 1 + ni[i] * Ji[i] * Math.pow(7.1 - Pi * 1, Ii[i]) * Math.pow(Tao * 1 - 1.222, Ji[i] - 1)
    };
    var hs = GAMt * Tao * R * (t * 1 + 273.15);
    return hs
};

function getTemp() {
    a = document.getElementById("input_five_1_2").value;
    result1 = ts(a);
    result1 = result1 > 1 ? result1.toFixed(2) : result1.toPrecision(3);
    document.getElementById("input_five_1_3").value = result1
}
function resultFIVE1() {
    clear();
    a = document.getElementById("input_five_1_1").value;
    b = document.getElementById("input_five_1_2").value;
    c = document.getElementById("input_five_1_3").value;
    d = document.getElementById("input_five_1_4").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (c < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(d)) return;
    add = document.getElementById("table_five_1");
    rows = add.rows.length;
    var vzz = vz(c, b);
    result1 = a * vzz / Math.pow(d / 2000, 2) / Math.PI / 3600;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>管道流速:" + result1 + "m/s</td>"
};

function resultFIVE2() {
    clear();
    a = document.getElementById("input_five_2_1").value;
    b = document.getElementById("input_five_2_2").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    add = document.getElementById("table_five_2");
    rows = add.rows.length;
    result1 = a / 1000 / Math.pow(b / 2000, 2) / Math.PI / 3600;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>管道流速:" + result1 + "m/s</td>"
};

function resultFIVE3() {
    clear();
    a = document.getElementById("input_five_3_1").value;
    b = document.getElementById("input_five_3_2").value;
    c = document.getElementById("input_five_3_3").value;
    if (!isNum(a)) return;
    if (b < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(c)) return;
    add = document.getElementById("table_five_3");
    rows = add.rows.length;
    result1 = a * (273 + b * 1) / 273 / Math.pow(c / 2000, 2) / Math.PI / 3600;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>管道流速:" + result1 + "m/s</td>"
};

function showTable() {
    document.getElementById("yczjtj").style.display = "block"
};

function resultFIVE4() {
    clear();
    a = document.getElementById("input_five_4_1").value;
    b = document.getElementById("input_five_4_2").value;
    c = document.getElementById("input_five_4_3").value;
    if (!isNum(a)) return;
    if (b < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(c)) return;
    add = document.getElementById("table_five_4");
    rows = add.rows.length;
    result1 = a * (273 + b * 1) / 273 / Math.pow((c / 2000), 2) / Math.PI / 3600;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>管道流速:" + result1 + "m/s</td>"
};

function resultFIVE5() {
    clear();
    a = document.getElementById("input_five_5_1").value;
    b = document.getElementById("input_five_5_2").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    add = document.getElementById("table_five_5");
    rows = add.rows.length;
    result1 = a / Math.pow(b / 2000, 2) / Math.PI / 3600;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>管道流速:" + result1 + "m/s</td>"
};

function resultSIX1() {
    clear();
    a = document.getElementById("input_six_1_1").value;
    if (a < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    add = document.getElementById("table_six_1");
    rows = add.rows.length;
    result1 = ps(a) * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>注：此处显示压力为表压</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>饱和水蒸气压力:" + result1 + "MPa</td>"
};

function resultSIX2() {
    clear();
    a = document.getElementById("input_six_2_1").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_six_2");
    rows = add.rows.length;
    result1 = ts(a) * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>注：此处显示压力为表压</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>饱和水蒸汽温度:" + result1 + "℃</td>"
};

function resultSIX3() {
    clear();
    a = document.getElementById("input_six_3_1").value;
    b = document.getElementById("input_six_3_2").value;
    if (a < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(b)) return;
    add = document.getElementById("table_six_3");
    rows = add.rows.length;
    result1 = hs(a, b) * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>注：此处显示压力为表压</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>水的焓值:" + result1 + "kj/kg</td>"
};

function resultSIX4() {
    clear();
    a = document.getElementById("input_six_4_1").value;
    b = document.getElementById("input_six_4_2").value;
    if (a < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(b)) return;
    add = document.getElementById("table_six_4");
    rows = add.rows.length;
    result1 = hz(a, b) * 1;
    result2 = vz(a, b) * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>注：此处显示压力为表压</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>水蒸汽的焓值:" + result1 + "kj/kg</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>水蒸汽的比容:" + result2 + "m3/kg</td>"
};

function resultSEVEN1() {
    clear();
    var num = 0;
    a = document.getElementById("input_seven_1_1").value;
    b = document.getElementById("input_seven_1_2").value;
    c = document.getElementById("input_seven_1_3").value;
    d = document.getElementById("input_seven_1_4").value;
    e = document.getElementById("input_seven_1_5").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (c < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (d < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(e)) return;
    add = document.getElementById("table_seven_1");
    rows = add.rows.length;
    if ((c * 1 - d * 1) < 0) {
        var temp = c * 1;
        c = d * 1;
        d = temp * 1
    }
    switch (a) {
    case "1":
        result1 = (c * 1 - d * 1) * 1000 / 8600 / e * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨热水</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨热水</td>";
        break;
    case "2":
        result1 = (c * 1 - d * 1) * 1000 / 3800 / e * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨热水</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨热水</td>";
        break;
    case "3":
        result1 = (c * 1 - d * 1) * 1000 / 11050 / e * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨热水</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨热水</td>";
        break;
    case "4":
        result1 = (c * 1 - d * 1) * 1000 / 12160 / e * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "kg/吨热水";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨热水</td>";
        break;
    case "5":
        result1 = (c * 1 - d * 1) * 1000 / 859.8 / e * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "kwh/吨热水</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨热水</td>";
        break
    }
};

function getTemp2() {
    a = document.getElementById("input_seven_2_3").value;
    result1 = ts(a);
    result1 = result1 > 1 ? result1.toFixed(2) : result1.toPrecision(3);
    document.getElementById("input_seven_2_4").value = result1
}
function resultSEVEN2() {
    clear();
    a = document.getElementById("input_seven_2_1").value;
    b = document.getElementById("input_seven_2_2").value;
    c = document.getElementById("input_seven_2_3").value;
    d = document.getElementById("input_seven_2_4").value;
    e = document.getElementById("input_seven_2_5").value;
    f = document.getElementById("input_seven_2_6").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (!isNum(c)) return;
    if (d < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (e < -273.5) {
        alert("请输入大于-273.5的值");
        return
    }
    if (!isNum(f)) return;
    add = document.getElementById("table_seven_2");
    rows = add.rows.length;
    switch (a) {
    case "1":
        result1 = (hz(d, c) - hs(e, c)) / 4.1868 * 1000 / 8600 / f * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨蒸汽</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨蒸汽</td>";
        break;
    case "2":
        result1 = (hz(d, c) - hs(e, c)) / 4.1868 * 1000 / 3800 / f * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨蒸汽</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨蒸汽</td>";
        break;
    case "3":
        result1 = (hz(d, c) - hs(e, c)) / 4.1868 * 1000 / 11050 / f * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "Nm3/吨蒸汽</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨蒸汽</td>";
        break;
    case "4":
        result1 = (hz(d, c) - hs(e, c)) / 4.1868 * 1000 / 12160 / f * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "kg/吨蒸汽";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨蒸汽</td>";
        break;
    case "5":
        result1 = (hz(d, c) - hs(e, c)) / 4.1868 * 1000 / 859.8 / f * 100;
        result2 = b * result1;
        result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
        result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
        add.insertRow(rows++).innerHTML = "<td name='result'>单位耗量:" + result1 + "kwh/吨蒸汽</td>";
        add.insertRow(rows++).innerHTML = "<td name='result'>估算成本:" + result2 + "元/吨蒸汽</td>";
        break
    }
}
function resultEIGHT1() {
    clear();
    a = document.getElementById("input_eight_1_1").value;
    if (!isNum(a)) return;
    result1 = a * 0.5;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add = document.getElementById("table_eight_1");
    rows = add.rows.length;
    add.insertRow(rows++).innerHTML = "<td name='result'>蒸汽量:" + result1 + "t/h</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestEIGHT(" + result1 + ",'table_eight_1')>炉型推荐</td>"
};

function resultEIGHT2() {
    clear();
    var ac = document.getElementById("input_eight_2_1");
    var bc = document.getElementById("input_eight_2_2");
    var cc = document.getElementById("input_eight_2_3");
    var dc = document.getElementById("input_eight_2_4");
    var e = document.getElementById("input_eight_2_5").value;
    if (ac.checked) {
        a = 6
    } else {
        a = 0
    };
    if (bc.checked) {
        b = 0.55
    } else {
        b = 0
    };
    if (cc.checked) {
        c = 0.5
    } else {
        c = 0
    };
    if (dc.checked) {
        d = 0.6
    } else {
        d = 0
    };
    add = document.getElementById("table_eight_2");
    rows = add.rows.length;
    result1 = e * (a * 1 + b * 1 + c * 1 + d * 1) / 1000;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>蒸汽量:" + result1 + "t/h</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestEIGHT(" + result1 + ",'table_eight_2')>炉型推荐</td>"
};

function resultEIGHT3() {
    clear();
    var ac = document.getElementById("input_eight_3_1");
    var bc = document.getElementById("input_eight_3_2");
    var cc = document.getElementById("input_eight_3_3");
    var dc = document.getElementById("input_eight_3_4");
    var ec = document.getElementById("input_eight_3_5");
    var f = document.getElementById("input_eight_3_6").value;
    var g = document.getElementById("input_eight_3_7").value;
    if (!isNum(f)) return;
    if (!isNum(g)) return;
    if (ac.checked) {
        a = 4.5
    } else {
        a = 0
    };
    if (bc.checked) {
        b = 0.45
    } else {
        b = 0
    };
    if (cc.checked) {
        c = 0.65
    } else {
        c = 0
    };
    if (dc.checked) {
        d = 0.6
    } else {
        d = 0
    };
    if (ec.checked) {
        e = 2.9
    } else {
        e = 0
    };
    add = document.getElementById("table_eight_3");
    rows = add.rows.length;
    result1 = (g * (a * 1 + b * 1 + c * 1 + d * 1) + f * e) / 1000;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>蒸汽量:" + result1 + "t/h</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'><a href='javascript:;' onclick=suggestEIGHT(" + result1 + ",'table_eight_3')>炉型推荐</td>"
};

function resultEIGHT4() {
    clear();
    a = document.getElementById("input_eight_4_1").value;
    if (!isNum(a)) return;
    add = document.getElementById("table_eight_4");
    rows = add.rows.length;
    result1 = a * 1;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    var pj = 0;
    var index = 0;
    var count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result'>推荐冷凝蒸汽锅炉</td>";
    for (var j = 1;; j++) {
        if (result1 <= 0) {
            alert("蒸汽量少于等于0，无法推荐");
            return
        }
        pj = result1 / j;
        if (pj > 0 && pj <= 2) {
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS2-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 2 && pj <= 3) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS3-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 3 && pj <= 4) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS4-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 4 && pj <= 5) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 5 && pj <= 5.22) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS6-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 5.22 && pj <= 6.96) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS8-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 6.96 && pj <= 8.7) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS10-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 8.7 && pj <= 10.44) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS12-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 10.44 && pj <= 13.05) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS15-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 13.05 && pj <= 17.4) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS20-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result'>推荐节能蒸汽锅炉</td>";
    for (var j = 1;; j++) {
        if (result1 <= 0) {
            alert("蒸汽量少于等于0，无法推荐");
            return
        }
        pj = result1 / j;
        if (pj > 1.5 && pj <= 2) {
            if (count == 1) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS2-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 1
        } else if (pj > 2 && pj <= 3) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS3-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 3 && pj <= 4) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS4-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 4 && pj <= 5) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 5 && pj <= 5.22) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS6-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 5.22 && pj <= 6.96) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS8-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 6.96 && pj <= 8.7) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS10-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 8.7 && pj <= 10.44) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS12-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 10.44 && pj <= 13.05) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS15-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 13.05 && pj <= 17.4) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS20-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 0 && pj < 0.5) {
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS0.5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 0.5 && pj <= 1) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS1-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 1 && pj <= 1.5) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result'>推荐WNS1.5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        }
    };
    add.insertRow(rows++).innerHTML = "<td name='result'>注：大型水管锅炉请联系本公司定制，销售电话：0510-86632366。</td>"
};

function resultNINE1() {
    clear();
    a = document.getElementById("input_nine_1_1").value;
    b = document.getElementById("input_nine_1_2").value;
    c = document.getElementById("input_nine_1_3").value;
    d = document.getElementById("input_nine_1_4").value;
    if (!isNum(a)) return;
    if (!isNum(b)) return;
    if (!isNum(c)) return;
    if (!isNum(d)) return;
    if (!isRight(d, 1, 5)) return;
    add = document.getElementById("table_nine_1");
    rows = add.rows.length;
    var gt = [1.0049, 0.5, 0.8793, 1.65];
    var yt = [0.8374, 2, 1.1305, 0];
    var trq = [1.1054, 0.02, 1.1807, 0.4];
    switch (a) {
    case "1":
        result1 = c * (gt[0] * b / 1000 + gt[1]);
        result2 = c * (gt[2] * b / 1000 + gt[3]) + (d * 1 - 1) * result1;
        break;
    case "2":
        result1 = c * (yt[0] * b / 1000 + yt[1]);
        result2 = c * (yt[2] * b / 1000 + yt[3]) + (d * 1 - 1) * result1;
        break;
    case "3":
        result1 = c * (trq[0] * b / 1000 + trq[1]);
        result2 = c * (trq[2] * b / 1000 + trq[3]) + (d * 1 - 1) * result1;
        break
    };
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    result2 = result2 > 1 ? result2.toFixed(3) : result2.toPrecision(3);
    add.insertRow(rows++).innerHTML = "<td name='result'>标况空气量" + result1 + "Nm3/h</td>";
    add.insertRow(rows++).innerHTML = "<td name='result'>标况烟气量" + result2 + "Nm3/h</td>"
};

function suggestTWO(value, str) {
    var result5 = value * 1;
    if (result5 <= 0) {
        alert("累计总热负荷小于等于0，无法推荐");
        return
    }
    add = document.getElementById(str);
    rows = add.rows.length;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'></td>";
    var pj = 0;
    var index = 0;
    var count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>冷凝热水锅炉:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 1400) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.1-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.8-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS3.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS4.2-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS5.6-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS7.0-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS8.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS10.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS14-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>真空热水机组:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 350) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ30-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 350 && pj <= 700) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ60-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 700 && pj <= 1050) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ90-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 3
        } else if (pj > 1050 && pj <= 1400) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ120-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 4
        } else if (pj > 1400 && pj <= 1750) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ180-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 5
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ210-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 6
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZZJ240-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 7
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ300-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 8
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ360-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ480-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ600-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ720-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 13) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ900-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 13
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 14) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐ZLJ1200-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 14
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>节能热水炉:</td>";
    for (var j = 1;; j++) {
        pj = result5 / j;
        if (pj > 0 && pj <= 350) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS0.35-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 350 && pj <= 700) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS0.7-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 700 && pj <= 1050) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.05-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 3
        } else if (pj > 1050 && pj <= 1400) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 4
        } else if (pj > 1400 && pj <= 1750) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS1.75-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 5
        } else if (pj > 1750 && pj <= 2100) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.1-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 6
        } else if (pj > 2100 && pj <= 2800) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS2.8-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 7
        } else if (pj > 2800 && pj <= 3500) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS3.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2;
            count = 8
        } else if (pj > 3500 && pj <= 4200) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS4.2-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 4200 && pj <= 5600) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS5.6-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 5600 && pj <= 7000) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS7.0-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 7000 && pj <= 8400) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS8.4-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        } else if (pj > 8400 && pj <= 10500) {
            if (count == 13) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS10.5-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 13
        } else if (pj > 10500 && pj <= 14000) {
            if (count == 14) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>推荐WNS14-1.0/95/70-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 14
        }
    };
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='3'>注：大型水管锅炉请联系本公司定制，销售电话：0510-86632366。</td>"
};

function suggestEIGHT(result, str) {
    result1 = result * 1;
    if (result1 <= 0) {
        alert("蒸汽量少于等于0，无法推荐");
        return
    }
    add = document.getElementById(str);
    rows = add.rows.length;
    result1 = result1 > 1 ? result1.toFixed(3) : result1.toPrecision(3);
    var pj = 0;
    var index = 0;
    var count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐冷凝蒸汽锅炉</td>";
    for (var j = 1;; j++) {
        pj = result1 / j;
        if (pj > 0 && pj <= 2) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS2-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 2 && pj <= 3) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS3-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 3 && pj <= 4) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS4-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 4 && pj <= 5) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 5 && pj <= 5.22) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS6-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 5.22 && pj <= 6.96) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS8-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 6.96 && pj <= 8.7) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS10-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 8.7 && pj <= 10.44) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS12-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 10.44 && pj <= 13.05) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS15-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 13.05 && pj <= 17.4) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS20-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        }
    };
    pj = 0;
    index = 0;
    count = 0;
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐节能蒸汽锅炉</td>";
    for (var j = 1;; j++) {
        if (result1 <= 0) {
            alert("蒸汽量少于等于0，无法推荐");
            return
        }
        pj = result1 / j;
        if (pj > 1.5 && pj <= 2) {
            if (count == 1) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS2-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 1
        } else if (pj > 2 && pj <= 3) {
            if (count == 2) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS3-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 2
        } else if (pj > 3 && pj <= 4) {
            if (count == 3) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS4-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 3
        } else if (pj > 4 && pj <= 5) {
            if (count == 4) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 4
        } else if (pj > 5 && pj <= 5.22) {
            if (count == 5) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS6-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 5
        } else if (pj > 5.22 && pj <= 6.96) {
            if (count == 6) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS8-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 6
        } else if (pj > 6.96 && pj <= 8.7) {
            if (count == 7) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS10-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 7
        } else if (pj > 8.7 && pj <= 10.44) {
            if (count == 8) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS12-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 8
        } else if (pj > 10.44 && pj <= 13.05) {
            if (count == 9) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS15-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 9
        } else if (pj > 13.05 && pj <= 17.4) {
            if (count == 10) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS20-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 10
        } else if (pj > 0 && pj < 0.5) {
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS0.5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            break
        } else if (pj > 0.5 && pj <= 1) {
            if (count == 11) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS1-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 11
        } else if (pj > 1 && pj <= 1.5) {
            if (count == 12) continue;
            add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>推荐WNS1.5-1.25-Y.Q,一共" + (j * 1 + 1 * 1) + "台,其中一台为备用</td>";
            index++;
            if (index == 3) break;
            count = 12
        }
    };
    add.insertRow(rows++).innerHTML = "<td name='result' colspan='2'>注：大型水管锅炉请联系本公司定制，销售电话：0510-86632366。</td>"
}
$(".container .li-tab .menudiv .spone").click(function(){
    var index =$(this).index();
    $(this).eq(index).addClass("color").parent("a").siblings().find(".spone").removeClass("color")
    $(this).eq(index).css('color','#fff').parent("a").siblings().find(".spone").css('color','#333');
})

