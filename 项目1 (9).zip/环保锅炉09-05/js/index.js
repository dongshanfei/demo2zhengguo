$(document).ready(function(e) {
	
/*-------------------------------banner-----------------------------------------*/
	
	$(".bannermain").css("display","block");
	$(".b1").animate({width:'420px'},1000);
	$(".b1").animate({height:'240px'},1000,function(){
		$(".b2").css("display","block");
		$(".b2").animate({width:'420px'},1000,function(){
			$(".b4").css("display","block");
			$(".b3").fadeIn(3000);
		});	
	});

/*-----------------------------政策---------------------------------------------*/	
	$("#zcmain1").mouseenter(function(){
		$("#zctxt1").fadeOut(800);
		$("#zcico1").fadeOut(800);	
		$("#zcmaintxt1").fadeIn(1000);
	});
	$("#zcmain1").mouseleave(function(){
		$("#zctxt1").fadeIn(800);
		$("#zcico1").fadeIn(800);	
		$("#zcmaintxt1").fadeOut(1000);
	});

	$("#zcmain2").mouseenter(function(){
		$("#zcmaintxt2").css("display","block");
		$("#zctxt2").animate({top:"-120px"},800);
		$("#zcico2").animate({top:"600px"},1200,function(){
			$("#zcmaintxt2").animate({opacity:'1'},1000);
		});	
	});
	$("#zcmain2").mouseleave(function(){
		$("#zcmaintxt2").css("display","none");
		$("#zcmaintxt2").animate({opacity:'0'},500,function(){
			$("#zctxt2").animate({top:"40px"},800);
			$("#zcico2").animate({top:"200px"},1200);
		});
	});
	
	$("#zcmain3").mouseenter(function(){
		$("#zcmaintxt3").css("display","block");
		$("#zctxt3").fadeOut(300,function(){
			$("#zcico3").animate({top:"-200px"},500,function(){
				$("#zcmaintxt3").animate({opacity:'1'},1000);
			});
		});
	});
	$("#zcmain3").mouseleave(function(){
		$("#zcmaintxt3").css("display","none");
		$("#zcico3").css("top","360px");
		$("#zcmaintxt3").animate({opacity:'0'},500,function(){
			$("#zctxt3").fadeIn(300);	
			$("#zcico3").animate({top:"200px"},300)
		});	
	});
/*------------------------------五重----------------------------------------*/
jQuery(".five1main").slide({ titCell:".inHd li",mainCell:".inBd" });
jQuery(".fivemain").slide();

/*---------------------------find-------------------------------------------*/
    $("#pt1").mouseover(function(){
			$("#pm1").fadeIn();
			$("#pm2").fadeOut();
			$("#pt1").addClass("parttabon");
			$("#pt2").removeClass("parttabon");
		});
		$("#pt2").mouseover(function(){
			$("#pm2").fadeIn();
			$("#pm1").fadeOut();	
			$("#pt1").removeClass("parttabon");
			$("#pt2").addClass("parttabon");
		});
		
		$("#pt3").mouseover(function(){
			$("#pm3").fadeIn();
			$("#pm4").fadeOut();
			$("#pt3").addClass("parttabon");
			$("#pt4").removeClass("parttabon");
		});
		$("#pt4").mouseover(function(){
			$("#pm4").fadeIn();
			$("#pm3").fadeOut();	
			$("#pt3").removeClass("parttabon");
			$("#pt4").addClass("parttabon");
		});
		
/*-----------------------------图片滚动------------------------------------------------*/		
	jQuery(".imgscroll").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:3});
});