
// 头部
$(document).ready(function(){
	$(".banner_text").animate({top:"200",opacity:"1"},1500);
	$("#woyaodong").animate({top:"80",opacity:"1"},1500);	
})

// 第一部分
$(document).ready(function(){
	$(".topical_one_pic .w1200>ul>li").hover(function(){
		$(this).find(".flag_text").hide();
		$(this).find(".flag").stop().animate({top:"0"},200).show();
	},function(){
		$(this).find(".flag_text").fadeIn(200);
		$(this).find(".flag").stop().animate({top:"68"},200).hide();
	});
})
//第二部分
//tab nav
$(function(){
	$(".topical_two .tab>li").mouseenter(function(){
		$(this).addClass("tab_current").siblings().removeClass("tab_current");
		var index = $(this).index();
		$(".tab_content_topline").children().eq(index).show().siblings().hide();
		$(".tab_content88").children().eq(index).show().siblings().hide();
	});
});

//tab_1
$(function(){
	var Run = true
	var Num = $("#slideWarp>li").length
	var NumHTML = "<ul id='little_title'>"

	for(var i = 1; i <=Num ; i++) {
		NumHTML+='<li>'+""+'</li>'
	};
	NumHTML+='</ul>'
	$("#slideWarp").after(NumHTML)


	function showSlide(i){
            
            if(i==$("#little_title>li").index($('#little_title .current'))){ 
                return null
            }

            $("#slideWarp>li").finish().filter(':visible').css({'z-index':'0'})
            					.fadeOut().end()
                        		.eq(i).css({'z-index':'9'})
                        		.fadeIn();
            $("#little_title>li").finish().filter('.current').removeClass("current").end()
                        		.eq(i).addClass('current');
        };
    showSlide(0)

    $("#little_title>li").on("mouseenter.enter",function(){
    	showSlide($("#little_title>li").index(this));
    });

   	$("#slideWarp,#little_title>li").hover(function(){
   		Run=false;
   	},function(){
   		Run=true;
   	});

	setInterval(function(){
		if (Run) {
				if ($("#little_title .current").next().length==0 ){
					$("#little_title>li").eq(0).triggerHandler("mouseenter.enter");
				}else{
					$("#little_title .current").next().triggerHandler("mouseenter.enter");
				}
		};
	},2000);

		 // var j=1
   //      setInterval(function(){
   //          if(j=='3'){j=0}
   //          showSlide(j)
   //          j++
   //      },1000)

});

//tab_4
$(function(){
	$("#tab_content4 .tab4_li").hover(function(){
		$(this).stop().animate({width:"284px",height:"433px"}).addClass("tab4_current").siblings().removeClass("tab_current")
	},function(){
		$(this).stop().animate({width:"255px",height:"386px"}).removeClass("tab4_current").siblings().animate({width:"255px"})
	});




});

//part 4
$(function(){
	$(".con_4_main").hover(function(){
		$(this).children(".zhezhao").fadeOut(200);
		$(this).children(".zhezhao_middle").fadeOut(200);
	},function(){
		$(this).children(".zhezhao").fadeIn(200);
		$(this).children(".zhezhao_middle").fadeIn(200);
	});


})
