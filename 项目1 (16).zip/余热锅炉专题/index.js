$(".container-3 .tab .ta").click(function(){
	var index = $(this).index()
	$(this).addClass("on").siblings().removeClass("on");
	$(".ta-content").eq(index).addClass("show").siblings().removeClass("show");
})
//
$(".one .one-1").hover(function(e){
	var e = e || event;
	$(e.target).siblings(".one-1-content").show();
})
$(".one-1-content").hover(function(){
	$(this).show();
},function(){
	$(this).hide();
})
$(".one .one-2").hover(function(e){
	var e = e || event;
	$(e.target).siblings(".one-1-content").show();
},function(){
	$(".one-1-content").hide()
})

//
$(".title-ul ul li img").hover(function(e){
	var e = e || event;
	$(e.target).siblings(".one").show();
})
$(".title-ul ul li .one").hover(function(){
	$(this).show();
},function(){
	$(this).hide();
})
//
$(".ta-content2 .img1").hover(function(){
	$(this).siblings(".img2").show();
})
$(".ta-content2 .img2").hover(function(){
	$(this).siblings(".img2").show();
},function(){
	$(this).fadeOut();

})

